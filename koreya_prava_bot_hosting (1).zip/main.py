# -*- coding: utf-8 -*-
"""Xosting (Bot-Hosting va b.) uchun ishga tushirish fayli.
Kerakli kutubxonani o'zi o'rnatadi va konsolga nima bo'layotganini aniq yozadi."""
import os
import site
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
os.chdir(HERE)
sys.path.insert(0, HERE)

print(f"[main] Python {sys.version.split()[0]} | papka: {HERE}", flush=True)
if sys.version_info < (3, 9):
    print("[main] XATO: Python 3.9 yoki yangiroq kerak. Xosting sozlamalaridan Python versiyasini oshiring.", flush=True)
    sys.exit(1)

has_token = os.environ.get("TELEGRAM_BOT_TOKEN") or os.environ.get("BOT_TOKEN")
print("[main] Token:", "topildi" if has_token else "TOPILMADI — Environment'ga TELEGRAM_BOT_TOKEN qo'shing", flush=True)
print("[main] images papkasi:", "bor" if os.path.isdir(os.path.join(HERE, "images")) else "YO'Q (rasmli savollar rasmsiz chiqadi)", flush=True)


def _pip(*args) -> int:
    return subprocess.call([sys.executable, "-m", "pip", "install", "--disable-pip-version-check",
                            "--retries", "2", "--timeout", "20", "-q", *args])


def ensure_deps() -> None:
    try:
        import telegram  # noqa: F401
        return
    except ImportError:
        pass
    req = os.path.join(HERE, "requirements.txt")
    print("[main] python-telegram-bot o'rnatilmoqda (1–2 daqiqa)...", flush=True)
    libs = os.path.join(HERE, "libs")
    for extra in ([], ["--user"], ["--target", libs]):
        if _pip(*extra, "-r", req) == 0:
            if extra[:1] == ["--target"]:
                sys.path.insert(0, libs)
            elif extra == ["--user"]:
                site.addsitedir(site.getusersitepackages())
            break
    import importlib
    importlib.invalidate_caches()
    try:
        import telegram
    except ImportError:
        print("[main] XATO: python-telegram-bot o'rnatilmadi. Yuqoridagi pip xabarini menga yuboring.", flush=True)
        sys.exit(1)
    print("[main] o'rnatildi, versiya:", telegram.__version__, flush=True)


ensure_deps()
from bot import main  # noqa: E402

if __name__ == "__main__":
    main()
