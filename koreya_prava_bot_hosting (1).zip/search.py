# -*- coding: utf-8 -*-
"""Savollar bankidan qidirish: koreyscha so'z, o'zbekcha so'z (lug'at orqali) yoki raqam."""
import re

import glossary
from quiz import QUESTIONS, TOTAL

_HANGUL = re.compile(r"[가-힣]")


def _norm(s: str) -> str:
    return re.sub(r"\s+", " ", s).strip().lower()


_MAIN = {qid: _norm(" ".join([q["q"], *q["ctx"], *q["o"]])) for qid, q in QUESTIONS.items()}
_STEM = {qid: _norm(q["q"]) for qid, q in QUESTIONS.items()}
_EXPL = {qid: _norm(q["e"]) for qid, q in QUESTIONS.items()}


def korean_terms_for(query: str, limit: int = 3) -> list:
    """O'zbekcha (lotin) so'zdan lug'at orqali koreyscha atamalarni topadi."""
    out = []
    for ko, _ in glossary.search(query):
        if ko not in out:
            out.append(ko)
        if len(out) >= limit:
            break
    return out


def search(query: str) -> dict:
    """{'ids': [...], 'terms': [...ishlatilgan koreyscha atamalar], 'mode': 'num'|'ko'|'uz'|'none'}"""
    q = _norm(query)
    if not q:
        return dict(ids=[], terms=[], mode="none")
    if q.isdigit():
        n = int(q)
        return dict(ids=[n] if 1 <= n <= TOTAL else [], terms=[], mode="num")

    if _HANGUL.search(q):
        terms = [q]
        mode = "ko"
    else:
        terms = [t.lower() for t in korean_terms_for(q)]
        mode = "uz"
        if not terms:
            return dict(ids=[], terms=[], mode="none")

    ids = []
    for qid in sorted(QUESTIONS):
        main, expl = _MAIN[qid], _EXPL[qid]
        if mode == "ko":
            toks = q.split(" ")
            hit_main = all(t in main for t in toks)
            hit_expl = (not hit_main) and all(t in main or t in expl for t in toks)
            hit = hit_main or hit_expl
        else:
            hit = any(t in main or t in expl for t in terms)
        if hit:
            in_stem = any(t in _STEM[qid] for t in (terms if mode == "uz" else q.split(" ")))
            ids.append((0 if in_stem else 1, qid))
    ids.sort()
    return dict(ids=[i for _, i in ids], terms=terms if mode == "uz" else [], mode=mode)


def snippet(qid: int, n: int = 28) -> str:
    s = QUESTIONS[qid]["q"]
    return s if len(s) <= n else s[:n - 1] + "…"
