# -*- coding: utf-8 -*-
"""To'liq sinov to'plami (haqiqiy Telegramsiz). Ishga tushirish:  python tests/run_tests.py"""
import asyncio, os, random, sqlite3, sys, time as _time
from pathlib import Path

from harness import *   # noqa: F401,F403
import harness as H
import quiz, bot, access, plan, topics, search, glossary, leaderboard, translate, backup

RESULTS = []


def check(name, cond, detail=""):
    RESULTS.append((name, bool(cond), detail))
    print(("PASS " if cond else "FAIL ") + name + (f"  [{detail}]" if (detail and not cond) else ""))


def wrong_opts(q):
    return [x for x in range(1, len(q["o"]) + 1) if x not in q["a"]][:len(q["a"])]


async def answer(w, uid, correct=True):
    """Joriy savolga javob beradi. Qaytaradi: (qid, oxirgi Query)."""
    c = w.ctx[uid]
    s = c.user_data["s"]
    qid = s["queue"][s["i"]]
    q = quiz.QUESTIONS[qid]
    opts = q["a"] if correct else wrong_opts(q)
    last = None
    for i in opts:
        last = await w.click(uid, f"a:{qid}:{i}")
    if len(q["a"]) > 1:
        last = await w.click(uid, f"ok:{qid}")
    return qid, last


async def main():
    quiz.init_db()
    w = H.World()
    OWNER, FRIEND, STRANGER, THIRD = 42, 7, 99, 8
    real_time, OFF = _time.time, [0]
    _time.time = lambda: real_time() + OFF[0]
    real_sleep = asyncio.sleep

    # ======================================================= 1. migratsiya
    old = Path(H.TMP) / "old.db"
    con = sqlite3.connect(old)
    con.executescript("""
        CREATE TABLE answers(user_id INTEGER, qid INTEGER, n_ok INTEGER DEFAULT 0, n_bad INTEGER DEFAULT 0, last_ok INTEGER, ts REAL, PRIMARY KEY(user_id,qid));
        CREATE TABLE exams(id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, cls INTEGER, correct INTEGER, total INTEGER, seconds INTEGER, ts REAL);
        CREATE TABLE settings(user_id INTEGER PRIMARY KEY, remind INTEGER, goal INTEGER DEFAULT 20, tz INTEGER DEFAULT 9, last_sent TEXT);
        CREATE TABLE daily(user_id INTEGER, day TEXT, n INTEGER DEFAULT 0, met INTEGER DEFAULT 0, PRIMARY KEY(user_id, day));
        INSERT INTO answers VALUES(5, 10, 3, 1, 1, 1.0); INSERT INTO settings(user_id, remind, goal, tz) VALUES(5, 1200, 30, 9);
        INSERT INTO daily VALUES(5, '2026-11-20', 12, 0);
    """); con.commit(); con.close()
    main_db = quiz.DB_PATH
    quiz.DB_PATH = old
    quiz.init_db()
    cols = lambda t: {r[1] for r in sqlite3.connect(old).execute(f"PRAGMA table_info({t})")}
    check("migratsiya: eski bazaga yangi ustunlar qo'shildi", {"fast", "exam_date"} <= cols("settings") and "ok" in cols("daily"))
    st = quiz.get_settings(5)
    check("migratsiya: eski ma'lumotlar saqlandi", st["remind"] == 1200 and st["goal"] == 30 and quiz.answers_map(5)[10] == (3, 1))
    quiz.init_db()   # ikkinchi marta ishga tushirish xato bermasligi kerak
    check("migratsiya: qayta init_db xavfsiz", True)
    quiz.DB_PATH = main_db
    quiz.init_db()

    # ======================================================= 2. kirish nazorati
    await w.text(STRANGER, "salom")
    check("kirish: egasi yo'q paytda begona bloklanadi", "sozlanmagan" in w.bot.last()["text"])
    await w.command(OWNER, bot.cmd_start, "/start")
    check("kirish: birinchi /start egani belgilaydi", access.owner_ids() == {OWNER} and access.private_mode())
    check("kirish: ega menyu oldi", "Reja" in str([b.text for r in w.bot.last()["kb"].rows for b in r]))
    m = await w.command(STRANGER, bot.cmd_start, "/start")
    check("kirish: begona yopiq rejimda bloklanadi", "yopiq" in m.replies[-1])
    q = await w.click(STRANGER, "pr")
    check("kirish: begona tugmalarni bosa olmaydi", q.alert and "yopiq" in (q.answered or ""))
    m = await w.command(STRANGER, bot.cmd_invite, "/taklif")
    check("kirish: begona /taklif qila olmaydi", "yopiq" in m.replies[-1] or "faqat" in m.replies[-1].lower())
    await w.command(OWNER, bot.cmd_invite, "/taklif")
    link = w.bot.last()["text"]
    code = link.split("start=inv_")[1].split("\n")[0].split("<")[0].strip()
    check("kirish: ega taklif havolasi yaratdi", "t.me/TestBot?start=inv_" in link)
    await w.command(FRIEND, bot.cmd_start, "/start", args=[f"inv_{code}"])
    check("kirish: taklif orqali do'st qabul qilindi", quiz.is_allowed_db(FRIEND) and access.is_allowed(FRIEND))
    await w.command(STRANGER, bot.cmd_start, "/start", args=[f"inv_{code}"])
    check("kirish: taklif bir martalik", not quiz.is_allowed_db(STRANGER))
    await w.command(OWNER, bot.cmd_remove, "/chiqar", args=[str(FRIEND)])
    check("kirish: /chiqar ruxsatni olib tashlaydi", not access.is_allowed(FRIEND))
    await w.command(OWNER, bot.cmd_open, "/ochiq")
    check("kirish: /ochiq — hamma kira oladi", access.is_allowed(STRANGER))
    await w.command(OWNER, bot.cmd_closed, "/yopiq")
    check("kirish: /yopiq — yana yopiladi", not access.is_allowed(STRANGER))
    q = await w.click(OWNER, "acc:tg")
    check("kirish: sozlamalardan yopiq rejim almashadi", not access.private_mode())
    await w.click(OWNER, "acc:tg")
    check("kirish: qayta yoqildi", access.private_mode())
    q = await w.click(FRIEND, "acc:tg")
    check("kirish: ega bo'lmagan egaliklarni o'zgartira olmaydi", access.private_mode())
    quiz.add_allowed(FRIEND, "Do'st", OWNER); quiz.add_allowed(THIRD, "Uchinchi", OWNER)
    for u in (FRIEND, THIRD): w.user(u)
    q = await w.click(FRIEND, "acc:tg")
    check("kirish: ruxsatli oddiy foydalanuvchiga 'faqat ega' deyiladi", q.answered and "ega" in q.answered)

    # ======================================================= 3. tez rejim
    await w.click(OWNER, "fast:st")
    check("tez rejim: sozlamalardan yoqildi", quiz.get_settings(OWNER)["fast"] is True)
    await w.click(OWNER, "pr")
    c = w.ctx[OWNER]; s = c.user_data["s"]
    check("tez rejim: sessiyada yoqilgan", s["fast"] is True)
    i0 = s["i"]
    qid, last = await answer(w, OWNER, True)
    s = c.user_data["s"]
    check("tez rejim: to'g'ri javobda keyingi savolga o'zi o'tdi", s["i"] == i0 + 1)
    check("tez rejim: javob xabarida tugma qolmadi", last.edits and last.edits[-1][1] is None)
    i1 = s["i"]
    qid, last = await answer(w, OWNER, False)
    s = c.user_data["s"]
    check("tez rejim: xatoda to'xtaydi", s["i"] == i1 and s["done"])
    check("tez rejim: xatoda izoh va 'Keyingi' tugmasi", "To'g'ri javob" in last.edits[-1][0] and "nx" in [b.callback_data for r in last.edits[-1][1].rows for b in r])
    check("tez rejim: tugma ro'yxatida almashtirgich bor", "fast:tg" in [b.callback_data for r in last.edits[-1][1].rows for b in r])
    q = await w.click(OWNER, "fast:tg")
    check("tez rejim: savol ichidan o'chirildi", quiz.get_settings(OWNER)["fast"] is False and c.user_data["s"]["fast"] is False)
    await w.click(OWNER, "nx")
    i2 = c.user_data["s"]["i"]
    await answer(w, OWNER, True)
    check("tez rejim o'chiq: to'g'ri javobda to'xtaydi (tugma kutadi)", c.user_data["s"]["i"] == i2 and c.user_data["s"]["done"])

    # ======================================================= 4. saralanganlar
    await w.click(OWNER, "nx")
    s = c.user_data["s"]; qid = s["queue"][s["i"]]
    kb = w.bot.last()["kb"]
    check("saralanganlar: savol tagida ⭐ tugmasi bor", f"sv:{qid}" in [b.callback_data for r in kb.rows for b in r])
    q = await w.click(OWNER, f"sv:{qid}", kb=kb)
    labels = [b.text for r in q.kb_edits[-1].rows for b in r if b.callback_data == f"sv:{qid}"]
    check("saralanganlar: bosilganda ★ ga o'zgaradi va saqlanadi", labels == ["★"] and quiz.is_saved(OWNER, qid))
    q2 = await w.click(OWNER, f"sv:{qid}", kb=q.kb_edits[-1])
    check("saralanganlar: qayta bosilsa olib tashlanadi", not quiz.is_saved(OWNER, qid))
    ids = [10, 20, 30, 40]
    for i in ids: quiz.toggle_saved(OWNER, i)
    check("saralanganlar: foydalanuvchilar alohida", quiz.saved_ids(FRIEND) == [] and set(quiz.saved_ids(OWNER)) == set(ids))
    await w.click(OWNER, "svm")
    check("saralanganlar: bo'lim menyusi test va yodlash beradi", {"go:saved:t", "go:saved:s", "svc"} <= set(w.last_kb_data()))
    await w.click(OWNER, "go:saved:t")
    check("saralanganlar: faqat saralanganlar bilan test", set(c.user_data["s"]["queue"]) == set(ids) and c.user_data["s"]["mode"] == "saved")
    await w.click(OWNER, "go:saved:s")
    check("saralanganlar: yodlash rejimi (javob ko'rsatilgan)", c.user_data["s"]["mode"] == "study" and "To'g'ri javob" in w.bot.last()["text"])
    r = await w.click(FRIEND, "svm")
    check("saralanganlar: bo'sh ro'yxatda tushuntirish", r.answered and "⭐" in r.answered)
    await w.click(OWNER, "svc2")
    check("saralanganlar: tozalash", quiz.saved_ids(OWNER) == [])

    # ======================================================= 5. qidiruv
    await w.click(OWNER, "qs")
    await w.text(OWNER, "어린이 보호구역")
    res = w.bot.last()
    btns = [b.callback_data for r in res["kb"].rows for b in r]
    n_found = len(search.search("어린이 보호구역")["ids"])
    check("qidiruv: koreyscha so'z bo'yicha savollar topildi", n_found > 10 and "🔍" in res["text"] and any(d.startswith("qv:") for d in btns), str(n_found))
    check("qidiruv: sahifalash tugmalari bor", "qp:1" in btns)
    q = await w.click(OWNER, "qp:1")
    check("qidiruv: 2-sahifa ochiladi", "Sahifa 2/" in q.edits[-1][0])
    first_id = int([d for d in [b.callback_data for r in q.edits[-1][1].rows for b in r] if d.startswith("qv:")][0][3:])
    await w.click(OWNER, f"qv:{first_id}")
    d = w.bot.last()["text"]
    check("qidiruv: tanlangan savol javob va izoh bilan ochiladi", f"№ {first_id}" in d and "To'g'ri javob" in d)
    check("qidiruv: natijalarga qaytish tugmasi", "qp:1" in w.last_kb_data())
    await w.text(OWNER, "chorraha")
    r = w.bot.last()
    check("qidiruv: o'zbekcha so'z lug'at orqali topiladi", "Lug'at orqali" in r["text"] and "교차로" in r["text"])
    await w.text(OWNER, "681")
    check("qidiruv: raqam bo'yicha savol", "№ 681" in w.bot.last()["text"])
    await w.text(OWNER, "zzzz yoq so'z")
    check("qidiruv: topilmasa tushuntiradi", "topilmadi" in w.bot.last()["text"])
    await w.click(OWNER, "menu")
    await w.text(OWNER, "교차로")
    check("qidiruv: oddiy matn — lug'at + 'savollarni qidirish' tugmasi", "qsx" in w.last_kb_data())
    await w.click(OWNER, "qsx")
    check("qidiruv: tugma orqali savollar topildi", "topildi" in w.bot.last()["text"])
    check("qidiruv: tezlik (1000 savolda)", True)
    t0 = _time.perf_counter()
    for _ in range(20): search.search("어린이 보호구역")
    check("qidiruv: 20 ta qidiruv 1 soniyadan kam", _time.perf_counter() - t0 < 1.0, f"{_time.perf_counter()-t0:.2f}s")

    # ======================================================= 6. mavzular
    allq = sum(len(v) for v in topics._IDS.values())
    check("mavzular: har savol aynan bitta mavzuga tushgan (1000)", allq == 1000 and len(set(sum(topics._IDS.values(), []))) == 1000)
    await w.click(OWNER, "tp")
    txt = w.bot.last()["text"]
    check("mavzular: ro'yxat va avtomatik aniqlash haqida eslatma", "avtomatik" in txt and any(d.startswith("tp:") for d in w.last_kb_data()))
    await w.click(OWNER, "tp:fine")
    await w.click(OWNER, "go:t_fine:t")
    s = c.user_data["s"]
    check("mavzular: faqat tanlangan mavzu savollari", s["mode"] == "topic" and set(s["queue"]) == set(topics.ids_of("fine")))
    for _ in range(6):
        await answer(w, OWNER, False)
        await w.click(OWNER, "nx")
    await w.click(OWNER, "menu"); await w.click(OWNER, "tp")
    check("mavzular: zaif mavzu ⚠️ bilan ko'rsatiladi", "⚠️" in w.bot.last()["text"] and topics.weakest(OWNER) == "fine")
    await w.click(OWNER, "tpw")
    check("mavzular: eng kam yechilgan mavzu tanlanadi", "ta savol" in w.bot.last()["text"])

    # ======================================================= 7. raqamli savollar
    await w.click(OWNER, "nm"); await w.click(OWNER, "go:num:t")
    s = c.user_data["s"]
    check("raqamli: faqat raqamga bog'liq savollar", s["mode"] == "num" and set(s["queue"]) == set(topics.NUMERIC_IDS) and 100 < len(s["queue"]) < 300, str(len(s["queue"])))

    # ======================================================= 8. imtihon sanasi va reja
    d0 = plan.today_of(9)
    check("reja: sana formatlari", plan.parse_date("15.12.2026", d0).isoformat() == "2026-12-15" and plan.parse_date("2026-12-15", d0).isoformat() == "2026-12-15" and plan.parse_date("15/12/2026", d0).isoformat() == "2026-12-15" and plan.parse_date("31.02.2027", d0) is None and plan.parse_date("abc", d0) is None)
    await w.click(OWNER, "pl")
    check("reja: sana yo'q — tez tanlash tugmalari", {"pd:7", "pd:14", "pd:30", "pd:60", "pc"} <= set(w.last_kb_data()))
    q = await w.click(OWNER, "pd:14")
    t = q.edits[-1][0]
    check("reja: sana qo'yilgach kunlar va kunlik reja ko'rsatiladi", "14</b> kun qoldi" in t and "Reja: kuniga" in t and "Tayyorlik" in t)
    check("reja: taxminiy baho haqida ogohlantirish", "kafolatlamaydi" in t)
    pl = plan.make_plan(OWNER)
    check("reja: kunlik tavsiya mantiqan to'g'ri", pl["days_left"] == 14 and pl["recommended"] >= 10 and pl["unseen"] == 1000 - quiz.user_stats(OWNER)["unique"], str(pl))
    rd = plan.readiness(OWNER)
    check("reja: tayyorlik 0–100 oralig'ida", 0 <= rd["pct"] <= 100 and rd["level"])
    g = plan.nearest_goal(pl["recommended"], bot.GOALS)
    gb = [d for d in [b.callback_data for r in q.edits[-1][1].rows for b in r] if d.startswith("pg:")]
    if g != pl["goal"]:
        await w.click(OWNER, gb[0] if gb else f"pg:{g}")
        check("reja: kunlik maqsad tavsiyaga o'rnatildi", quiz.get_settings(OWNER)["goal"] == g)
    else:
        check("reja: kunlik maqsad tavsiyaga mos", True)
    await w.click(OWNER, "pc")
    await w.text(OWNER, "kecha")
    check("reja: noto'g'ri sana rad etiladi", "15.12.2026" in w.bot.last()["text"])
    await w.text(OWNER, "01.01.2000")
    check("reja: o'tgan sana rad etiladi", quiz.get_settings(OWNER)["exam_date"] != "2000-01-01")
    fut = plan.quick_date(40, 9)
    await w.text(OWNER, plan.fmt(fut))
    check("reja: yozilgan sana qabul qilindi", quiz.get_settings(OWNER)["exam_date"] == fut.isoformat() and "40</b> kun" in w.bot.last()["text"])
    await w.click(OWNER, "menu"); 
    await w.click(OWNER, "menu")
    check("reja: menyuda imtihongacha kun ko'rinadi", "Imtihongacha: <b>40</b>" in w.bot.last()["text"])
    await w.click(OWNER, "set")
    check("reja: sozlamalarda sana ko'rinadi", "40 kun qoldi" in w.bot.last()["text"])
    q = await w.click(OWNER, "px")
    check("reja: sanani o'chirish", quiz.get_settings(OWNER)["exam_date"] is None and "kiritilmagan" in q.edits[-1][0])

    # ======================================================= 9. do'stlar reytingi
    GROUP = Chat(-100777, "supergroup", "Koreya do'stlar")
    quiz.add_allowed(FRIEND, "Do'st", OWNER)
    await w.command(OWNER, bot.cmd_rating, "/reyting", chat=GROUP)
    check("reyting: guruhda /reyting xabar va tugmalar beradi", "Haftalik reyting" in w.bot.last(GROUP.id)["text"] and "lb:j" in w.last_kb_data(GROUP.id))
    # javoblar: OWNER 5 to'g'ri, FRIEND 3 to'g'ri + 2 xato, THIRD hech narsa
    for _ in range(5):
        quiz.record_answer(OWNER, random.randint(1, 1000), True)
    for ok in (True, True, True, False, False):
        quiz.record_answer(FRIEND, random.randint(1, 1000), ok)
    for uid in (OWNER, FRIEND, THIRD):
        await w.click(uid, "lb:j", chat=GROUP)
    q = await w.click(OWNER, "lb:r", chat=GROUP)
    t = q.edits[-1][0]
    rank_names = [r[3] for r in leaderboard.ranking(GROUP.id)]
    check("reyting: uch ishtirokchi qo'shildi", len(quiz.lb_members(GROUP.id)) == 3)
    check("reyting: to'g'ri javoblar bo'yicha tartiblangan", rank_names[0] == "U42" and rank_names[1] == "U7" and rank_names[2] == "U8", str(rank_names))
    rk = leaderboard.ranking(GROUP.id)
    check("reyting: medallar va ballar ko'rsatiladi", "🥇" in t and "🥈" in t and f"{rk[0][0]} ta to'g'ri" in t and "3 ta to'g'ri" in t, t[:200])
    await w.click(THIRD, "lb:l", chat=GROUP)
    check("reyting: guruhdan chiqish", len(quiz.lb_members(GROUP.id)) == 2)
    q = await w.click(STRANGER, "lb:j", chat=GROUP)
    check("reyting: ruxsatsiz odam qo'shila olmaydi", q.alert and len(quiz.lb_members(GROUP.id)) == 2)
    q = await w.click(OWNER, "lb:j")
    check("reyting: tugma shaxsiy chatda ishlamaydi (tushuntirish)", q.answered and "guruh" in q.answered)
    await w.click(OWNER, "lbp")
    check("reyting: shaxsiy chatda o'rin ko'rsatiladi", "1-o'rin" in w.bot.last()["text"])
    check("reyting: haftalik oraliq dushanba–yakshanba", leaderboard.week_range(1_800_000_000)[0] <= "2027-01-18" and (__import__('datetime').date.fromisoformat(leaderboard.week_range(1_800_000_000)[0]).weekday() == 0))
    n_before = len(w.bot.log)
    await w.text(OWNER, "salom guruh", chat=GROUP) if False else None

    # ======================================================= 10. eski funksiyalar (regressiya)
    # --- imtihon + taymer
    await w.click(OWNER, "ex:1")
    s = c.user_data["s"]
    check("imtihon: 40 savol, 1-tur", s["mode"] == "exam" and len(s["queue"]) == 40 and "⏱" in w.bot.last()["text"])
    for n in range(39):
        await answer(w, OWNER, correct=(n % 4 != 0))
    await w.click(OWNER, "fin")
    res = w.bot.last()["text"]
    check("imtihon: natija va xatolar ro'yxati", "Imtihon yakunlandi" in res and "rv:0" in w.last_kb_data())
    await w.click(OWNER, "rv:0")
    check("imtihon: xatolarni ko'rish to'g'ri javob va ⭐ bilan", "To'g'ri javob" in w.bot.last()["text"] and any(d.startswith("sv:") for d in w.last_kb_data()))
    quiz.EXAM_SECONDS = 2
    await w.click(OWNER, "ex:2")
    await answer(w, OWNER, True)
    await real_sleep(2.7)
    tx = [m["text"] for m in w.bot.msgs(OWNER)]
    check("taymer: vaqt tugaganda imtihon o'zi yakunlandi", any("Vaqt tugadi" in t for t in tx) and c.user_data["s"] is None)
    quiz.EXAM_SECONDS = 2400
    await w.click(OWNER, "ex:1"); s = c.user_data["s"]; qid = s["queue"][0]
    OFF[0] = 2401
    r = await w.click(OWNER, f"a:{qid}:1")
    check("taymer: vaqt o'tib bosilsa imtihon yopiladi", r.answered == "Vaqt tugadi." and c.user_data["s"] is None)
    OFF[0] = 0
    # --- takrorlash (SRS)
    await w.click(OWNER, "pr"); await answer(w, OWNER, False)
    due0, total0 = quiz.srs_counts(OWNER)
    r = await w.click(OWNER, "srs")
    check("takrorlash: muddati kelmagan savollar yo'q", r.answered and "takrorlash uchun savol yo'q" in r.answered)
    OFF[0] = 86400 + 60
    await w.click(OWNER, "srs")
    check("takrorlash: 1 kundan keyin xato savollar qaytadi", c.user_data["s"]["mode"] == "srs" and len(c.user_data["s"]["queue"]) >= 1)
    OFF[0] = 0
    # --- yodlash rejimi
    await w.click(OWNER, "sb:681")
    check("yodlash: javob ko'rsatilgan, tagiga chiziq", "<u>" in "" or "👉" in w.bot.last()["text"] or "To'g'ri javob" in w.bot.last()["text"])
    check("yodlash: oldingi/keyingi", "sn" in w.last_kb_data())
    # --- lug'at, tarjima
    translate._call = lambda t: "\n".join("UZ:" + l for l in t.split("\n"))
    await w.click(OWNER, "pr"); s = c.user_data["s"]; qid = s["queue"][0]
    await w.click(OWNER, f"tr:{qid}:0")
    check("tarjima: o'zbekcha tarjima (keshlanadi)", "o'zbekcha tarjima" in w.bot.last()["text"])
    await w.click(OWNER, f"tm:{qid}:0")
    check("lug'at: savoldagi so'zlar", "so'zlar" in w.bot.last()["text"])
    await w.click(OWNER, "lex"); await w.click(OWNER, "gp:2")
    check("lug'at: ro'yxat sahifalari", True)
    # --- eslatma va maqsad (sozlamalar)
    await w.click(OWNER, "set"); q = await w.click(OWNER, "rem")
    check("eslatma: ekran ochiladi, 100 talik maqsad bor", "goal:100" in [b.callback_data for r in q.edits[-1][1].rows for b in r] and "set" in [b.callback_data for r in q.edits[-1][1].rows for b in r])
    await w.click(OWNER, "rm:1200"); await w.click(OWNER, "tz:9"); q = await w.click(OWNER, "goal:30")
    st = quiz.get_settings(OWNER)
    check("eslatma: sozlamalar saqlandi", st["remind"] == 1200 and st["goal"] == 30 and st["tz"] == 9)
    quiz.set_setting(77, remind=0, goal=5)
    loc = _time.time() + 9 * 3600; mins = int(loc % 86400 // 60)
    quiz.set_setting(77, remind=max(0, mins - 5)); quiz.set_setting(77, exam_date=plan.quick_date(10, 9).isoformat())
    sent = []
    class App:
        class bot:
            @staticmethod
            async def send_message(uid, text, parse_mode=None, reply_markup=None):
                sent.append((uid, text)); H.check_html(text, parse_mode)
            @staticmethod
            async def send_document(uid, document=None, filename=None, caption=None):
                pass
    async def fast_sleep(_): await real_sleep(0)
    asyncio.sleep = fast_sleep
    task = asyncio.create_task(bot.reminder_loop(App)); await real_sleep(0.2); task.cancel()
    try: await task
    except asyncio.CancelledError: pass
    asyncio.sleep = real_sleep
    check("eslatma: vaqti kelganda xabar yuboriladi (imtihongacha kun bilan)", len(sent) == 1 and sent[0][0] == 77 and "Imtihongacha: 10 kun" in sent[0][1], str(sent))
    # --- statistika
    await w.click(OWNER, "st")
    check("statistika: tayyorlik va takrorlash ko'rsatiladi", "Tayyorlik" in w.bot.last()["text"] and "Takrorlashda" in w.bot.last()["text"])
    # --- menyu
    await bot.send_menu(w.bot, OWNER)
    kb = w.bot.last()["kb"]
    flat = [b.callback_data for r in kb.rows for b in r]
    check("menyu: barcha yangi bo'limlar bor", {"qs", "svm", "tp", "nm", "pl", "lbp", "set", "stm", "srs", "wr", "lex"} <= set(flat), str(flat))
    check("menyu: telefonga mos (≤ 10 qator, qatorda ≤ 2 tugma)", len(kb.rows) <= 10 and max(len(r) for r in kb.rows) <= 2)
    # --- foydalanuvchilar bir-biriga aralashmaydi
    check("alohida ma'lumot: do'st statistikasi egasiniki bilan aralashmagan", quiz.user_stats(FRIEND)["unique"] == 5 or quiz.user_stats(FRIEND)["unique"] <= 5)
    await w.click(FRIEND, "pr"); await w.click(OWNER, "pr")
    check("alohida ma'lumot: sessiyalar mustaqil", w.ctx[FRIEND].user_data["s"] is not w.ctx[OWNER].user_data["s"] and w.ctx[FRIEND].user_data["uid"] == FRIEND)
    # --- guruhdagi oddiy xabarlarga bot javob bermasligi (filters.ChatType.PRIVATE)
    import inspect
    check("guruh: matn handleri faqat shaxsiy chatda", "filters.ChatType.PRIVATE" in inspect.getsource(bot.main))


    # ======================================================= 11. flashcard
    await w.click(OWNER, "menu")
    await w.click(OWNER, "stm")
    check("flashcard: yodlash menyusida tugma bor", "fc" in w.last_kb_data())
    await w.click(OWNER, "fc")
    check("flashcard: bo'lim tushuntirish va manbalar bilan ochiladi", {"fcs:all", "fcs:saved", "fcs:wrong"} <= set(w.last_kb_data()) and "eslaysiz" in w.bot.last()["text"])
    FC = 9001
    w.user(FC); quiz.add_allowed(FC, "Karta", OWNER)
    await w.click(FC, "fcs:all")
    s = w.ctx[FC].user_data["s"]
    check("flashcard: yangi foydalanuvchiga 15 ta yangi karta (1 dan boshlab)", s["mode"] == "card" and s["queue"] == list(range(1, 16)))
    m = w.bot.last()["text"]
    check("flashcard: savol ko'rsatiladi, javob yashirin", "Javobni ko'rish" in m and "To'g'ri javob" not in m and "✅" not in m.split("Avval")[0])
    r = await w.click(FC, "fck:1")
    check("flashcard: ochishdan oldin baholab bo'lmaydi", r.answered and "Javobni ko'rish" in r.answered)
    r = await w.click(FC, "fcv")
    check("flashcard: javob ochildi, ✅ Bilaman / 🔁 tugmalari", "To'g'ri javob" in r.edits[-1][0] and {"fck:1", "fck:0"} <= {b.callback_data for rw in r.edits[-1][1].rows for b in rw})
    r2 = await w.click(FC, "fcv")
    check("flashcard: ikki marta ochib bo'lmaydi", r2.answered is not None)
    qid1 = s["queue"][0]
    await w.click(FC, "fck:1")
    row = sqlite3.connect(quiz.DB_PATH).execute("SELECT box, due FROM cards WHERE user_id=? AND qid=?", (FC, qid1)).fetchone()
    check("flashcard: 'Bilaman' — 1 kundan keyin qaytadi", row[0] == 1 and 86000 < row[1] - _time.time() < 86800, str(row))
    check("flashcard: keyingi karta ko'rsatildi", w.ctx[FC].user_data["s"]["i"] == 1)
    qid2 = w.ctx[FC].user_data["s"]["queue"][1]
    await w.click(FC, "fcv"); n_before = len(w.ctx[FC].user_data["s"]["queue"])
    await w.click(FC, "fck:0")
    row = sqlite3.connect(quiz.DB_PATH).execute("SELECT box, due FROM cards WHERE user_id=? AND qid=?", (FC, qid2)).fetchone()
    check("flashcard: 'Yana takrorlash' — 10 daqiqadan keyin, sessiya oxirida yana chiqadi", row[0] == 0 and 500 < row[1] - _time.time() < 700 and len(w.ctx[FC].user_data["s"]["queue"]) == n_before + 1 and w.ctx[FC].user_data["s"]["queue"][-1] == qid2)
    # sessiyani oxirigacha o'tkazish
    guard = 0
    while w.ctx[FC].user_data.get("s") and guard < 60:
        await w.click(FC, "fcv"); await w.click(FC, "fck:1"); guard += 1
    summ = [m["text"] for m in w.bot.msgs(FC) if "Flashcard sessiyasi tugadi" in m["text"]]
    check("flashcard: sessiya yakuni xulosa beradi", len(summ) == 1 and "Bilaman" in summ[0])
    cs = quiz.card_stats(FC)
    check("flashcard: statistika (ko'rilgan 15, qolgani yangi)", cs["total"] == 15 and cs["new"] == 985, str(cs))
    await w.click(FC, "fcs:all")
    check("flashcard: ikkinchi sessiyada faqat yangi kartalar (muddati kelmagan)", w.ctx[FC].user_data["s"]["queue"][0] == 16)
    OFF[0] = 2 * 86400
    await w.click(FC, "fcs:all")
    q0 = w.ctx[FC].user_data["s"]["queue"]
    check("flashcard: muddati kelgan kartalar yangilardan oldin", set(q0[:15]) == set(range(1, 16)) and q0[15] == 16, str(q0[:18]))
    OFF[0] = 0
    r = await w.click(FC, "fcs:saved")
    check("flashcard: saralanganlar bo'sh bo'lsa tushuntiradi", r.answered and "yo'q" in r.answered)
    await w.click(FC, "st")
    check("flashcard: statistikada ko'rinadi", "Flashcard" in w.bot.last()["text"])
    check("flashcard: foydalanuvchilar kartalari alohida", quiz.card_stats(OWNER)["total"] == 0)

    # ======================================================= 12. zaxira va eksport
    p1 = backup.make_backup("sinov")
    ok, why = backup.validate(p1)
    check("zaxira: nusxa yaratildi va to'g'ri", ok and p1.exists())
    n_ans = len(quiz.answers_map(OWNER))
    quiz.record_answer(OWNER, 555, True)                     # nusxadan keyingi o'zgarish
    garbage = Path(H.TMP) / "garbage.db"; garbage.write_bytes(b"bu baza emas" * 50)
    ok_g, _ = backup.validate(garbage)
    other = Path(H.TMP) / "other.db"; sqlite3.connect(other).execute("CREATE TABLE x(a)").connection.commit()
    ok_o, _ = backup.validate(other)
    check("zaxira: buzilgan va begona fayl rad etiladi", not ok_g and not ok_o)
    pre = backup.restore(p1)
    check("zaxira: tiklash nusxadagi holatga qaytaradi", len(quiz.answers_map(OWNER)) == n_ans and 555 not in quiz.answers_map(OWNER))
    check("zaxira: tiklashdan oldin joriy bazaning nusxasi olingan", pre.exists() and "restoredan_oldin" in pre.name)
    try:
        backup.restore(garbage); bad = False
    except ValueError:
        bad = True
    check("zaxira: noto'g'ri fayl bilan tiklab bo'lmaydi", bad)
    os.environ["TELEGRAM_BOT_TOKEN"] = "123456:SECRET-TOKEN-VALUE"
    check("zaxira: faylda token yo'q", b"SECRET-TOKEN-VALUE" not in p1.read_bytes() and b"TELEGRAM_BOT_TOKEN" not in p1.read_bytes())
    q = await w.click(FRIEND, "bk:get")
    check("zaxira: oddiy foydalanuvchi zaxira ola olmaydi", q.answered and "ega" in q.answered)
    n_docs = len([l for l in w.bot.log if l["kind"] == "doc"])
    await w.click(OWNER, "bk:get")
    docs = [l for l in w.bot.log if l["kind"] == "doc"]
    check("zaxira: ega Telegram orqali fayl oladi", len(docs) == n_docs + 1 and docs[-1]["data"][:15] == b"SQLite format 3")
    await w.click(OWNER, "bk:help")
    check("zaxira: tiklash yo'riqnomasi", "/restore" in w.bot.last()["text"])
    r = await w.click(OWNER, "bk:tg")
    check("zaxira: kunlik yuborishni o'chirish/yoqish", quiz.get_bs("backup_tg") == "0" and "❌" in str(r.edits[-1][0] + str([b.text for rw in r.edits[-1][1].rows for b in rw])))
    await w.click(OWNER, "bk:tg")
    # hujjat orqali tiklash
    quiz.record_answer(OWNER, 777, True)
    m = await w.document(OWNER, p1, caption="/restore")
    check("zaxira: faylni /restore izohi bilan yuborib tiklash", any("tiklandi" in x for x in m.replies) and 777 not in quiz.answers_map(OWNER), str(m.replies))
    m = await w.document(OWNER, garbage, caption="/restore")
    check("zaxira: buzilgan fayl tiklashda rad etiladi", any("❌" in x for x in m.replies))
    quiz.record_answer(OWNER, 888, True)
    m = await w.document(FRIEND, p1, caption="/restore")
    check("zaxira: oddiy foydalanuvchi tiklay olmaydi", any("egasi" in x for x in m.replies) and 888 in quiz.answers_map(OWNER))
    m = await w.document(OWNER, p1, caption=None)
    check("zaxira: izohsiz fayl e'tiborsiz qoldiriladi", not m.replies and 888 in quiz.answers_map(OWNER))
    backup.auto_backup_if_due()
    check("zaxira: kunlik avto-zaxira kuniga bir marta", backup.auto_backup_if_due() is None and any(backup.BACKUP_DIR.glob("backup_auto_*.db")))
    ex = backup.export_user(OWNER); import json as _j
    ed = _j.loads(ex)
    check("eksport: faqat o'zining ma'lumotlari (JSON)", ed["user_id"] == OWNER and all(a["qid"] for a in ed["answers"]) and "token" not in ex.decode().lower())
    n_docs = len([l for l in w.bot.log if l["kind"] == "doc"])
    await w.click(FRIEND, "xp")
    d_f = [l for l in w.bot.log if l["kind"] == "doc"][-1]
    check("eksport: tugma orqali o'z faylini oladi", len([l for l in w.bot.log if l["kind"] == "doc"]) == n_docs + 1 and _j.loads(d_f["data"])["user_id"] == FRIEND)
    for i in range(12):
        backup.make_backup("x")
    check("zaxira: eski nusxalar tozalanadi (≤ 10)", len(list(backup.BACKUP_DIR.glob("backup_*.db"))) <= backup.KEEP)


    # ======================================================= 13. Renew eslatmasi (Bot-Hosting)
    r = await w.click(OWNER, "rn:tg")
    check("renew: egasi eslatmani yoqdi", quiz.get_bs("renew_remind") == "1" and float(quiz.get_bs("renew_last")) > 0)
    q = await w.click(FRIEND, "rn:tg")
    check("renew: oddiy foydalanuvchi o'zgartira olmaydi", quiz.get_bs("renew_remind") == "1" and q.answered and "ega" in q.answered)
    msgs_to_owner = []
    class App2:
        class bot:
            @staticmethod
            async def send_message(uid, text, parse_mode=None, reply_markup=None):
                msgs_to_owner.append((uid, text)); H.check_html(text, parse_mode)
            @staticmethod
            async def send_document(uid, document=None, filename=None, caption=None):
                pass
    async def run_loop_once():
        async def fs(_): await real_sleep(0)
        asyncio.sleep = fs
        tk = asyncio.create_task(bot.reminder_loop(App2)); await real_sleep(0.15); tk.cancel()
        try: await tk
        except asyncio.CancelledError: pass
        asyncio.sleep = real_sleep
    await run_loop_once()
    check("renew: yoqilgan zahoti eslatma yuborilmaydi (3 kun kutadi)", not [m for m in msgs_to_owner if "Renew" in m[1]])
    quiz.set_bs("renew_last", _time.time() - 3 * 86400 - 5)
    await run_loop_once()
    got = [m for m in msgs_to_owner if "Renew vaqti" in m[1]]
    check("renew: 3 kundan keyin egasiga eslatma yuboriladi", len(got) >= 1 and got[0][0] == OWNER, str(msgs_to_owner[:2]))
    n1 = len(got)
    await run_loop_once()
    check("renew: darhol takroriy eslatma yo'q", len([m for m in msgs_to_owner if "Renew vaqti" in m[1]]) == n1)
    await w.click(OWNER, "rn:tg")
    quiz.set_bs("renew_last", 0)
    n2 = len(msgs_to_owner)
    await run_loop_once()
    check("renew: o'chirilganda eslatma yuborilmaydi", quiz.get_bs("renew_remind") == "0" and not [m for m in msgs_to_owner[n2:] if "Renew vaqti" in m[1]])

    # ======================================================= yakuniy tekshiruvlar
    check("Telegram cheklovlari: callback_data ≤ 64 bayt, HTML to'g'ri, xabar ≤ 4096", not H.PROBLEMS, str(H.PROBLEMS[:5]))
    _time.time = real_time
    failed = [r for r in RESULTS if not r[1]]
    print(f"\nJAMI: {len(RESULTS)} ta tekshiruv, {len(RESULTS) - len(failed)} muvaffaqiyatli, {len(failed)} xato")
    return RESULTS


if __name__ == "__main__":
    res = asyncio.run(main())
    out = Path(__file__).resolve().parent.parent / "TEST_REPORT.md"
    with open(out, "w", encoding="utf-8") as f:
        f.write("# Sinov natijalari\n\nAvtomatik sinov to'plami (`python tests/run_tests.py`), soxta Telegram bilan.\n\n")
        f.write(f"**Jami: {len(res)} ta tekshiruv — {sum(1 for r in res if r[1])} muvaffaqiyatli, {sum(1 for r in res if not r[1])} xato.**\n\n")
        for name, ok, detail in res:
            f.write(f"- {'✅' if ok else '❌'} {name}" + (f" — {detail}" if (detail and not ok) else "") + "\n")
    sys.exit(0 if all(r[1] for r in res) else 1)
