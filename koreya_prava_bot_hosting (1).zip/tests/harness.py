# -*- coding: utf-8 -*-
"""Telegramsiz sinash uchun soxta (stub) muhit."""
import os, re, sys, tempfile, asyncio

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "stubs"))
sys.path.insert(0, os.path.dirname(HERE))
TMP = tempfile.mkdtemp(prefix="botdata_")
os.environ["DATA_DIR"] = TMP
os.environ.pop("OWNER_ID", None)
os.environ.pop("ADMIN_IDS", None)

import quiz, bot  # noqa: E402

PROBLEMS = []     # HTML/limit buzilishlari


def check_markup(kb):
    if kb is None:
        return
    for row in kb.rows:
        for b in row:
            if b.callback_data is not None and len(b.callback_data.encode()) > 64:
                PROBLEMS.append(("callback>64", b.callback_data))


def check_html(t, parse):
    if parse != "HTML":
        return
    st = []
    for m in re.finditer(r"<(/?)(b|u|i|code)>", t):
        if not m.group(1):
            st.append(m.group(2))
        elif not st or st.pop() != m.group(2):
            PROBLEMS.append(("html-nesting", t[:60]))
    if st:
        PROBLEMS.append(("html-unclosed", t[:60]))
    rest = re.sub(r"</?(b|u|i|code)>", "", t)
    if "<" in rest or ">" in rest or re.search(r"&(?!amp;|lt;|gt;)", rest):
        PROBLEMS.append(("html-stray", t[:60]))
    if len(t) > 4096:
        PROBLEMS.append(("too-long", len(t)))


class Chat:
    def __init__(self, id, type="private", title=""):
        self.id, self.type, self.title = id, type, title


class User:
    def __init__(self, id, name="User"):
        self.id, self.first_name = id, name


class P:
    def __init__(self, i): self.file_id = f"FID{i}"


class Sent:
    def __init__(self, i, chat_id, text="", kb=None):
        self.message_id, self.chat_id, self.photo, self.text, self.reply_markup = i, chat_id, [P(i)], text, kb


class FakeBot:
    username = "TestBot"

    def __init__(self):
        self.log, self.n = [], 0

    async def send_message(self, chat_id, text, parse_mode=None, reply_markup=None):
        self.n += 1
        check_html(text, parse_mode); check_markup(reply_markup)
        self.log.append(dict(kind="msg", chat=chat_id, text=text, kb=reply_markup))
        return Sent(self.n, chat_id, text, reply_markup)

    async def send_document(self, chat_id, document, filename=None, caption=None):
        self.n += 1
        self.log.append(dict(kind="doc", chat=chat_id, text=str(filename or document), kb=None, caption=caption,
                             data=(document.read() if hasattr(document, "read") else open(document, "rb").read())))
        return Sent(self.n, chat_id)

    async def send_photo(self, chat_id, photo):
        self.n += 1
        self.log.append(dict(kind="photo", chat=chat_id, text=str(photo), kb=None))
        return Sent(self.n, chat_id)

    async def send_media_group(self, chat_id, media):
        out = []
        for m in media:
            self.n += 1
            self.log.append(dict(kind="photo", chat=chat_id, text=str(m.media), kb=None))
            out.append(Sent(self.n, chat_id))
        return out

    def msgs(self, chat=None):
        return [l for l in self.log if l["kind"] == "msg" and (chat is None or l["chat"] == chat)]

    def last(self, chat=None):
        return self.msgs(chat)[-1]


class FakeFile:
    def __init__(self, path): self.path = path
    async def download_to_drive(self, dest):
        import shutil; shutil.copy(self.path, dest)


class FakeDocument:
    def __init__(self, path):
        self.path, self.file_size = path, os.path.getsize(path)
    async def get_file(self): return FakeFile(self.path)


class Message:
    def __init__(self, chat, text="", kb=None, bot=None, document=None, caption=None):
        self.chat, self.chat_id, self.text, self.reply_markup = chat, chat.id, text, kb
        self.document, self.caption = document, caption
        self._bot = bot
        self.replies = []

    async def reply_text(self, text, **kw):
        self.replies.append(text)
        if self._bot is not None:
            self._bot.log.append(dict(kind="msg", chat=self.chat_id, text="REPLY:" + text, kb=None))


class Query:
    def __init__(self, data, user, message):
        self.data, self.from_user, self.message = data, user, message
        self.answered, self.alert, self.edits, self.kb_edits = None, False, [], []

    async def answer(self, text=None, show_alert=False):
        self.answered, self.alert = text, show_alert

    async def edit_message_text(self, text, parse_mode=None, reply_markup=None):
        check_html(text, parse_mode); check_markup(reply_markup)
        self.edits.append((text, reply_markup))
        self.message.reply_markup = reply_markup

    async def edit_message_reply_markup(self, reply_markup=None):
        check_markup(reply_markup)
        self.kb_edits.append(reply_markup)
        self.message.reply_markup = reply_markup


class Update:
    def __init__(self, user, chat, query=None, message=None):
        self.effective_user, self.effective_chat = user, chat
        self.callback_query, self.message = query, message


class Ctx:
    def __init__(self, fbot, args=None):
        self.bot, self.user_data, self.args = fbot, {}, args or []


class World:
    """Bir nechta foydalanuvchi va bitta bot."""
    def __init__(self):
        self.bot = FakeBot()
        self.ctx = {}
        self.users = {}

    def user(self, uid, name=None):
        if uid not in self.users:
            self.users[uid] = User(uid, name or f"U{uid}")
            self.ctx[uid] = Ctx(self.bot)
        return self.users[uid], self.ctx[uid]

    async def click(self, uid, data, chat=None, kb=None):
        u, c = self.user(uid)
        chat = chat or Chat(uid)
        msg = Message(chat, kb=kb, bot=self.bot)
        q = Query(data, u, msg)
        await bot.on_callback(Update(u, chat, query=q), c)
        return q

    async def text(self, uid, text, chat=None):
        u, c = self.user(uid)
        chat = chat or Chat(uid)
        msg = Message(chat, text=text, bot=self.bot)
        await bot.on_text(Update(u, chat, message=msg), c)
        return msg

    async def document(self, uid, path, caption=None):
        u, c = self.user(uid)
        chat = Chat(uid)
        msg = Message(chat, bot=self.bot, document=FakeDocument(path), caption=caption)
        await bot.on_document(Update(u, chat, message=msg), c)
        return msg

    async def command(self, uid, fn, text="/cmd", args=None, chat=None):
        u, c = self.user(uid)
        c.args = args or []
        chat = chat or Chat(uid)
        msg = Message(chat, text=text, bot=self.bot)
        await fn(Update(u, chat, message=msg), c)
        return msg

    def last_kb_data(self, chat=None):
        m = self.bot.last(chat)
        return [b.callback_data for row in (m["kb"].rows if m["kb"] else []) for b in row]
