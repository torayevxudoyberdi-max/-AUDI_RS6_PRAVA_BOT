class _Any:
    def __init__(self,*a,**k): pass
    def __call__(self,*a,**k): return self
    def __getattr__(self,n): return _Any()
    def __and__(self,o): return self
    def __invert__(self): return self
Application=CallbackQueryHandler=CommandHandler=MessageHandler=PersistenceInput=PicklePersistence=_Any
class ContextTypes: DEFAULT_TYPE=None
filters=_Any()
