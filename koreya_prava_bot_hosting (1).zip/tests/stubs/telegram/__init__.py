class InlineKeyboardButton:
    def __init__(self, text, callback_data=None): self.text=text; self.callback_data=callback_data
class InlineKeyboardMarkup:
    def __init__(self, rows): self.rows=rows; self.inline_keyboard=rows
class InputMediaPhoto:
    def __init__(self, media): self.media=media
class Update: ALL_TYPES=None
