# -*- coding: utf-8 -*-
"""Koreyscha → o'zbekcha yo'l harakati atamalari lug'ati (qo'lda tuzilgan) va savoldan avtomatik topish."""
import re

from quiz import esc

_G = [
    ("Yo'l va joylar", [
        ("교차로", "chorraha"), ("횡단보도", "piyodalar o'tish joyi (zebra)"), ("보도", "trotuar"),
        ("차도", "qatnov qismi (avtomobillar yo'li)"), ("차로", "yo'l polosasi (qatori)"),
        ("차선", "polosa chizig'i"), ("중앙선", "markaziy chiziq"), ("갓길", "yo'l yoqasi (to'xtash yo'lagi)"),
        ("고속도로", "avtomagistral (tezyurar yo'l)"), ("자동차전용도로", "faqat avtomobillar yo'li"),
        ("일방통행", "bir tomonlama harakat"), ("터널", "tunnel"), ("교량", "ko'prik"),
        ("비탈길", "nishab yo'l"), ("오르막", "ko'tarilish (tepalik)"), ("내리막", "pastga tushish yo'li"),
        ("철길건널목", "temir yo'l kesishmasi"), ("안전지대", "xavfsizlik oroli"),
        ("회전교차로", "aylanma chorraha"), ("로터리", "aylanma harakat joyi"),
        ("나들목", "magistralga kirish-chiqish joyi (IC)"), ("분기점", "yo'l ayrilishi (JC)"),
        ("램프", "ulanish yo'li (rampa)"), ("휴게소", "dam olish maskani"),
        ("졸음쉼터", "uyqu bosganda dam olish joyi"), ("주차장", "to'xtab turish joyi (parkovka)"),
        ("정류장", "bekat"), ("버스전용차로", "faqat avtobus polosasi"), ("통행료", "yo'l to'lovi"),
        ("하이패스", "Hi-Pass (avtomatik yo'l to'lovi)"), ("점자블록", "ko'zi ojizlar uchun tekstura plitkasi"),
        ("소화전", "o't o'chirish gidranti"), ("노면", "yo'l yuzasi"),
        ("어린이 보호구역", "bolalar himoya hududi (maktab zonasi)"),
        ("노인 보호구역", "keksalar himoya hududi"), ("장애인", "nogiron (imkoniyati cheklangan shaxs)"),
        ("도로", "yo'l"), ("가장자리", "chekka"), ("중앙", "markaz (o'rta)"),
        ("맞은편", "qarama-qarshi tomon"), ("반대편", "qarshi tomon"), ("우측", "o'ng tomon"),
        ("좌측", "chap tomon"), ("전방", "old tomon"), ("후방", "orqa tomon"), ("측방", "yon tomon"),
        ("앞차", "oldingi mashina"), ("뒤차", "orqadagi mashina"),
        ("커브길", "burilish (egri) yo'l"), ("고갯길", "dovon yo'li"), ("비포장도로", "asfaltlanmagan yo'l"),
    ]),
    ("Harakat va manevrlar", [
        ("직진", "to'g'ri yurish"), ("좌회전", "chapga burilish"), ("우회전", "o'ngga burilish"),
        ("유턴", "U-burilish"), ("진로변경", "polosani o'zgartirish"), ("앞지르기", "quvib o'tish"),
        ("추월", "quvib o'tish"), ("끼어들기", "oraga kirib olish"), ("양보", "yo'l berish"),
        ("우선", "ustuvorlik"), ("통행", "o'tish (harakatlanish)"), ("진입", "kirish"), ("진출", "chiqish"),
        ("합류", "yo'lga qo'shilish"), ("후진", "orqaga yurish"), ("주행", "harakatlanish"),
        ("정속", "bir xil tezlikda"), ("감속", "tezlikni pasaytirish"), ("가속", "tezlashtirish"),
        ("회피", "chetlab o'tish"), ("횡단", "kesib o'tish"), ("보행", "piyoda yurish"),
        ("통과", "o'tib ketish"), ("대기", "kutish"), ("출발", "yo'lga chiqish"), ("도착", "yetib kelish"),
        ("목적지", "manzil"), ("지그재그", "zigzag"), ("직전", "darhol oldin"), ("직후", "darhol keyin"),
        ("인접", "qo'shni (yaqin)"),
    ]),
    ("To'xtash va tezlik", [
        ("정지", "to'xtash"), ("일시정지", "to'liq to'xtab, atrofni ko'rib o'tish (stop)"),
        ("정차", "qisqa to'xtash"), ("주차", "to'xtab turish (parkovka)"),
        ("서행", "sekin yurish (tezlikni keskin pasaytirib)"), ("정지선", "to'xtash chizig'i"),
        ("속도", "tezlik"), ("제한속도", "tezlik chegarasi"), ("최고속도", "maksimal tezlik"),
        ("최저속도", "minimal tezlik"), ("시속", "soatiga (km/soat)"), ("과속", "tezlikni oshirish"),
        ("안전거리", "xavfsiz masofa"), ("제동", "tormozlash"), ("제동거리", "tormoz yo'li"),
        ("정지거리", "to'liq to'xtash masofasi"), ("공주거리", "reaksiya masofasi (tormozgacha bosib o'tilgan yo'l)"),
        ("급제동", "keskin tormoz"), ("급정지", "keskin to'xtash"), ("급출발", "keskin yo'lga chiqish"),
        ("급가속", "keskin tezlashish"), ("구간단속", "uchastka bo'yicha tezlik nazorati"),
        ("단속", "nazorat (jarima kameralari bilan tekshiruv)"), ("무인단속", "avtomatik kamera nazorati"),
    ]),
    ("Svetofor, belgi va chiziqlar", [
        ("신호등", "svetofor"), ("신호기", "signal beruvchi qurilma"), ("신호", "signal"),
        ("신호위반", "svetofor qoidasini buzish"), ("보행신호", "piyodalar svetofori"),
        ("적색", "qizil"), ("황색", "sariq"), ("녹색", "yashil"), ("점멸", "miltillash"),
        ("비보호", "himoyasiz (alohida strelkasiz)"), ("화살표", "strelka"), ("안전표지", "yo'l belgisi"),
        ("주의표지", "ogohlantiruvchi belgi"), ("규제표지", "taqiqlovchi/cheklovchi belgi"),
        ("지시표지", "buyuruvchi belgi"), ("보조표지", "qo'shimcha belgi"),
        ("노면표시", "yo'l chiziqlari va yozuvlari"), ("실선", "yaxlit chiziq"), ("점선", "uzuq chiziq"),
        ("금지", "taqiq"), ("제한", "cheklov"), ("허용", "ruxsat"), ("우회", "aylanib o'tish"),
        ("방향지시등", "burilish ko'rsatkichi (povorotnik)"), ("비상등", "avariya chiroqlari"),
        ("전조등", "old chiroq (fara)"), ("미등", "gabarit chiroq"), ("안개등", "tuman chirog'i"),
        ("후진등", "orqaga yurish chirog'i"), ("제동등", "tormoz chirog'i"), ("경음기", "signal (klakson)"),
        ("경적", "klakson ovozi"), ("상향등", "uzoq nurli fara"), ("하향등", "yaqin nurli fara"),
    ]),
    ("Haydovchi, guvohnoma va jarima", [
        ("운전자", "haydovchi"), ("운전면허", "haydovchilik guvohnomasi"), ("면허증", "guvohnoma (plastik karta)"),
        ("학과시험", "nazariy imtihon"), ("기능시험", "maydonda (amaliy) imtihon"),
        ("도로주행", "yo'lda haydash imtihoni"), ("연습면허", "o'quv (amaliyot) guvohnomasi"),
        ("임시운전증명서", "vaqtinchalik haydovchi guvohnomasi"), ("국제운전면허", "xalqaro haydovchilik guvohnomasi"),
        ("외국면허", "xorijiy guvohnoma"), ("적성검사", "layoqat tekshiruvi (ko'rish va salomatlik)"),
        ("갱신", "yangilash"), ("신규", "yangi (birinchi marta)"), ("취소", "bekor qilish"),
        ("면허정지", "guvohnomani vaqtincha to'xtatish"), ("면허취소", "guvohnomani bekor qilish"),
        ("벌점", "jarima ballari"), ("범칙금", "jarima (yengil qoidabuzarlik uchun)"),
        ("과태료", "ma'muriy to'lov (jarima)"), ("벌금", "sud jarimasi"), ("징역", "qamoq jazosi"),
        ("구류", "qisqa muddatli hibs"), ("감경", "kamaytirish (yengillashtirish)"), ("가중", "og'irlashtirish"),
        ("위반", "qoidabuzarlik"), ("처벌", "jazolash"), ("초보운전", "yangi (tajribasiz) haydovchi"),
        ("노인운전자", "keksa haydovchi"), ("보호자", "vasiy (ota-ona)"), ("운전", "haydash"),
        ("운행", "qatnash (yurish)"), ("도로교통법", "Yo'l harakati qonuni"),
        ("시행규칙", "qonun ijro qoidalari"), ("시행령", "qonun ijro farmoni"),
        ("이내", "ichida (shu son ham kiradi)"), ("이상", "va undan yuqori (shu son kiradi)"),
        ("이하", "va undan past (shu son kiradi)"), ("미만", "dan kam (shu son kirmaydi)"),
        ("초과", "dan ortiq (shu son kirmaydi)"),
    ]),
    ("Xavfli holat va hodisalar", [
        ("교통사고", "yo'l-transport hodisasi"), ("사고", "hodisa"), ("부상", "jarohat"), ("사망", "o'lim"),
        ("중상", "og'ir jarohat"), ("경상", "yengil jarohat"), ("뺑소니", "hodisa joyidan qochish"),
        ("도주", "qochib ketish"), ("구호조치", "jabrlanuvchiga yordam ko'rsatish"),
        ("충돌", "to'qnashuv"), ("추돌", "orqadan urib yuborish"), ("전복", "ag'darilish"),
        ("음주운전", "mast holda haydash"), ("혈중알코올농도", "qondagi alkogol miqdori"),
        ("음주측정", "alkogol o'lchash"), ("졸음운전", "uyquda haydash"), ("과로", "charchoq"),
        ("난폭운전", "xavfli (tajovuzkor) haydash"), ("보복운전", "qasos maqsadida xavfli haydash"),
        ("안전운전", "xavfsiz haydash"), ("방어운전", "ehtiyotkor (himoyaviy) haydash"),
        ("양보운전", "yo'l berib haydash"), ("보험", "sug'urta"), ("책임보험", "majburiy sug'urta"),
        ("종합보험", "to'liq (qo'shimcha) sug'urta"), ("합의", "kelishuv"), ("피해자", "jabrlanuvchi"),
        ("가해자", "aybdor tomon"), ("과실", "aybdorlik (xato)"), ("응급처치", "birinchi tibbiy yordam"),
        ("심폐소생술", "yurak-o'pka reanimatsiyasi"), ("지혈", "qon to'xtatish"), ("인공호흡", "sun'iy nafas"),
        ("화재", "yong'in"), ("소화기", "o't o'chirgich"), ("삼각대", "ogohlantiruvchi uchburchak"),
        ("고장", "buzilish"), ("견인차", "evakuator (tortuvchi mashina)"), ("견인", "tortib olib ketish"),
        ("구난차", "yordam (evakuator) mashinasi"),
    ]),
    ("Transport turlari", [
        ("승용자동차", "yengil avtomobil"), ("승합자동차", "yo'lovchi avtomobili (mikroavtobus/avtobus)"),
        ("화물자동차", "yuk avtomobili"), ("특수자동차", "maxsus avtomobil"), ("건설기계", "qurilish texnikasi"),
        ("이륜자동차", "ikki g'ildirakli avtomobil (mototsikl)"), ("원동기장치자전거", "motorli velosiped (moped)"),
        ("자전거", "velosiped"), ("개인형 이동장치", "shaxsiy harakat vositasi (elektr samokat va b.)"),
        ("전동킥보드", "elektr samokat"), ("긴급자동차", "shoshilinch avtomobil (tez yordam, o't o'chirish, politsiya)"),
        ("구급차", "tez yordam mashinasi"), ("소방차", "o't o'chirish mashinasi"), ("경찰", "politsiya"),
        ("어린이통학버스", "bolalar maktab avtobusi"), ("택시", "taksi"), ("버스", "avtobus"),
        ("트레일러", "tirkama (treyler)"), ("트랙터", "traktor (tyagach)"), ("대형", "katta"), ("중형", "o'rta"),
        ("소형", "kichik"), ("전기자동차", "elektromobil"), ("수소", "vodorod"), ("하이브리드", "gibrid"),
        ("자율주행", "o'zi boshqaruvchi (avtopilot)"), ("블랙박스", "videoregistrator"),
        ("내비게이션", "navigator"), ("휴대전화", "mobil telefon"), ("번호판", "davlat raqami"),
        ("자동차", "avtomobil"),
    ]),
    ("Avtomobil qismlari va texnik", [
        ("엔진오일", "dvigatel moyi"), ("엔진", "dvigatel"), ("냉각수", "sovutish suyuqligi"), ("연료", "yoqilg'i"),
        ("배터리", "akkumulyator"), ("브레이크", "tormoz"), ("타이어", "shina"), ("변속기", "uzatmalar qutisi"),
        ("클러치", "debriyaj"), ("핸들", "rul"), ("조향", "boshqarish (rul tizimi)"),
        ("현가장치", "osma tizim (amortizator)"), ("계기판", "asboblar paneli"), ("안전띠", "xavfsizlik kamari"),
        ("에어백", "havo yostig'i"), ("와이퍼", "shisha tozalagich (dvornik)"), ("후사경", "orqa ko'rish oynasi"),
        ("사이드미러", "yon ko'zgu"), ("안전모", "himoya shlemi"), ("적재", "yuk ortish"), ("화물", "yuk"),
        ("승차정원", "yo'lovchi sig'imi"), ("승차", "mashinaga chiqish (o'tirish)"), ("하차", "mashinadan tushish"),
        ("승객", "yo'lovchi"), ("동승자", "hamrohlik qiluvchi yo'lovchi"), ("정기검사", "davriy texnik ko'rik"),
        ("점검", "tekshiruv"), ("등록", "ro'yxatdan o'tkazish"), ("매연", "chiqindi tutun"),
        ("배출가스", "chiqindi gaz"), ("일산화탄소", "is gazi (CO)"), ("대기오염", "havo ifloslanishi"),
        ("소음", "shovqin"), ("마찰", "ishqalanish"), ("관성", "inersiya"), ("원심력", "markazdan qochma kuch"),
        ("충격", "zarba"), ("수막현상", "suv qatlami ustida sirpanish (gidroplaning)"),
        ("페이드현상", "tormoz qizib samarasiz bo'lib qolishi (fade)"),
        ("베이퍼록", "tormoz suyuqligi bug'lanib tormoz ishlamay qolishi"),
        ("스탠딩웨이브", "shinada to'lqin hosil bo'lishi (standing wave)"),
        ("사각지대", "ko'r zona"), ("시야", "ko'rish maydoni"),
    ]),
    ("Ob-havo va yo'l holati", [
        ("야간", "tun (kechasi)"), ("안개", "tuman"), ("빗길", "nam yo'l (yomg'irli)"), ("눈길", "qorli yo'l"),
        ("빙판길", "muzli yo'l"), ("결빙", "muzlash"), ("폭우", "kuchli yomg'ir"), ("강풍", "kuchli shamol"),
        ("언덕", "tepalik"), ("급커브", "keskin burilish"), ("좁은 길", "tor yo'l"),
    ]),
]

# Har savolda chiqaversa halaqit beradigan juda umumiy so'zlar — faqat ro'yxat/qidiruvda
_NOAUTO = {"운전", "도로", "운전자", "도로교통법", "운행", "우측", "좌측", "전방", "후방", "측방", "앞차", "뒤차",
           "가장자리", "중앙", "맞은편", "반대편", "자동차", "사고", "주행", "통행", "속도"}
# 숫자 뒤에서만 의미 있는 단어 (이상/이하 ...)
_BOUND = {"이내", "이상", "이하", "미만", "초과"}
_BOUND_RE = re.compile(
    r"(?:(?<=[\d세년월일분초원점명인대회%터간톤])|(?<=[\d세년월일분초원점명인대회%터간톤] ))(이내|이상|이하|미만|초과)"
)

ENTRIES = []          # (kategoriya, ko, uz)
_UZ = {}
for _cat, _items in _G:
    for _ko, _uz in _items:
        if _ko not in _UZ:
            ENTRIES.append((_cat, _ko, _uz))
        _UZ[_ko] = _uz
_AUTO = sorted((k for k in _UZ if k not in _NOAUTO and k not in _BOUND), key=lambda k: -len(k))


def find_terms(text: str, limit: int = 14) -> list:
    taken = [False] * len(text)
    found = {}
    for ko in _AUTO:
        start = 0
        while True:
            i = text.find(ko, start)
            if i < 0:
                break
            if not any(taken[i:i + len(ko)]):
                for k in range(i, i + len(ko)):
                    taken[k] = True
                found.setdefault(ko, i)
            start = i + 1
    for m in _BOUND_RE.finditer(text):
        found.setdefault(m.group(1), m.start())
    order = sorted(found, key=lambda k: found[k])
    return [(k, _UZ[k]) for k in order][:limit]


def terms_for(q: dict, with_expl: bool = False) -> list:
    parts = [q["q"], *q["ctx"], *q["o"]]
    if with_expl and q["e"]:
        parts.append(q["e"])
    return find_terms("\n".join(parts), limit=22 if with_expl else 14)


def format_terms(title: str, terms: list) -> str:
    lines = [f"📚 <b>{esc(title)}</b>", ""]
    lines += [f"• <b>{esc(ko)}</b> — {esc(uz)}" for ko, uz in terms]
    return "\n".join(lines)


def search(query: str) -> list:
    q = query.strip().lower()
    if len(q) < 2:
        return []
    return [(ko, uz) for _, ko, uz in ENTRIES if q in ko.lower() or q in uz.lower()]


PAGE = 25
PAGES = (len(ENTRIES) + PAGE - 1) // PAGE


def page(k: int):
    k = max(0, min(k, PAGES - 1))
    chunk = ENTRIES[k * PAGE:(k + 1) * PAGE]
    lines, last = [f"🔤 <b>Lug'at</b> — {k + 1}/{PAGES}"], None
    for cat, ko, uz in chunk:
        if cat != last:
            lines += ["", f"<b>— {esc(cat)} —</b>"]
            last = cat
        lines.append(f"• <b>{esc(ko)}</b> — {esc(uz)}")
    return "\n".join(lines), k
