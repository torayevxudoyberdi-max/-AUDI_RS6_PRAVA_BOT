# -*- coding: utf-8 -*-
"""Zaxira nusxa, tiklash va foydalanuvchi ma'lumotlarini eksport qilish.
Token va maxfiy kalitlar bazada saqlanmaydi, shuning uchun zaxira faylida ham yo'q."""
import json
import sqlite3
import time
from pathlib import Path

import quiz

BACKUP_DIR = quiz.DATA_DIR / "backups"
KEEP = 10
NEEDED_TABLES = {"answers", "exams", "settings", "daily"}


def _copy_db(src_path, dst_path) -> None:
    src = sqlite3.connect(src_path)
    dst = sqlite3.connect(dst_path)
    try:
        src.backup(dst)
    finally:
        dst.close()
        src.close()


def make_backup(tag: str = "auto") -> Path:
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    dest = BACKUP_DIR / f"backup_{tag}_{time.strftime('%Y%m%d_%H%M%S')}.db"
    _copy_db(quiz.DB_PATH, dest)
    files = sorted(BACKUP_DIR.glob("backup_*.db"), key=lambda p: p.stat().st_mtime)
    for old in files[:-KEEP]:
        old.unlink(missing_ok=True)
    return dest


def validate(path) -> tuple:
    try:
        con = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
        try:
            if con.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
                return False, "Fayl buzilgan (integrity_check)."
            tables = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        finally:
            con.close()
    except sqlite3.DatabaseError:
        return False, "Bu SQLite zaxira fayli emas."
    missing = NEEDED_TABLES - tables
    if missing:
        return False, "Bu botning zaxira fayli emas (jadval yo'q: " + ", ".join(sorted(missing)) + ")."
    return True, "ok"


def restore(path) -> Path:
    """Tiklashdan oldin joriy bazaning nusxasini oladi. Qaytaradi: o'sha nusxa yo'li."""
    ok, msg = validate(path)
    if not ok:
        raise ValueError(msg)
    pre = make_backup("restoredan_oldin")
    _copy_db(path, quiz.DB_PATH)
    quiz.init_db()                      # eski zaxiradagi sxemani yangilaydi
    return pre


def auto_backup_if_due(max_age: float = 86400):
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    files = sorted(BACKUP_DIR.glob("backup_auto_*.db"), key=lambda p: p.stat().st_mtime)
    if files and time.time() - files[-1].stat().st_mtime < max_age:
        return None
    return make_backup("auto")


def export_user(uid: int) -> bytes:
    """Foydalanuvchining faqat o'z ma'lumotlari (JSON)."""
    with quiz._db() as c:
        def rows(sql):
            cur = c.execute(sql, (uid,))
            names = [d[0] for d in cur.description]
            return [dict(zip(names, r)) for r in cur.fetchall()]
        data = dict(
            user_id=uid,
            exported_at=time.strftime("%Y-%m-%d %H:%M:%S"),
            answers=rows("SELECT qid, n_ok, n_bad, last_ok, ts FROM answers WHERE user_id=?"),
            saved=rows("SELECT qid, ts FROM saved WHERE user_id=?"),
            exams=rows("SELECT cls, correct, total, seconds, ts FROM exams WHERE user_id=?"),
            daily=rows("SELECT day, n, ok, met FROM daily WHERE user_id=?"),
            srs=rows("SELECT qid, box, due FROM srs WHERE user_id=?"),
            cards=rows("SELECT qid, box, due, reps FROM cards WHERE user_id=?"),
            settings=rows("SELECT remind, goal, tz, fast, exam_date FROM settings WHERE user_id=?"),
        )
    return json.dumps(data, ensure_ascii=False, indent=1).encode("utf-8")
