# 🚗 Koreya haydovchilik guvohnomasi — Telegram o'quv boti (v3)

Manba: «1·2종 학과시험 문제은행 (2026.3.9 시행)» — 1000 ta savol (287 tasi rasmli).
Koreyscha savol va variantlar **o'zgartirilmagan**. O'zbekcha tarjima — mashina tarjimasi (taxminiy).

## Yangilash (yangi bot kerak emas!)
Token va bot o'sha qoladi. Kodni yangi zip bilan almashtiring va botni qayta ishga tushiring.
Statistika (`data.db`) saqlanadi — eski baza avtomatik yangilanadi.

## Ishga tushirish
```
pip install -r requirements.txt
cp .env.example .env        # .env ichiga tokenni yozing   (Windows: copy)
python bot.py
```
Muhit o'zgaruvchisi ham bo'ladi: `TELEGRAM_BOT_TOKEN` yoki `BOT_TOKEN`.
- **Termux (Android):** `pkg install python unzip`, zip'ni oching, yuqoridagi buyruqlar.
- **FadeHost:** zip'ni yuklang, start fayl `bot.py`, Environment: `TELEGRAM_BOT_TOKEN`.
- **Colab:** `koreya_prava_bot_colab.ipynb` (nested zip bilan).

## Birinchi ishga tushirishdan keyin — MUHIM
Botga **birinchi bo'lib `/start` yuboring** — siz bot egasi bo'lasiz va bot **yopiq rejimga** o'tadi
(faqat siz va siz taklif qilganlar ishlata oladi). Xohlasangiz egasini `.env` da `OWNER_ID=` bilan
oldindan belgilang (ID ni bilish: botga `/id`).

## Imkoniyatlar
- 📖 **Yodlash rejimi** — javob darrov ko'rsatiladi: to'g'ri javob <u>tagiga chiziq</u>, raqam/kalit so'zlar **qalin**.
  🃏 **Flashcard** — savolni ko'rasiz, javobni eslaysiz, «Javobni ko'rish» → «Bilaman» / «Yana takrorlash»
  (1→3→7→14→30 kunlik oraliq).
- 🎯 **Tasodifiy mashq**, 🔁 **Takrorlash** (xatolar 1/3/7 kundan keyin qaytadi), ❌ **Xatolarim**.
- ⚡ **Tez rejim** — to'g'ri javobda keyingi savolga o'zi o'tadi; xatoda izoh bilan to'xtaydi.
- 📝 **Imtihon** (1-tur 70, 2-tur 60 ball; 40 savol, 40 daqiqa taymer, vaqt tugasa o'zi yakunlanadi).
- 🧩 **Mavzular bo'yicha mashq** — kalit so'zlar bo'yicha AVTOMATIK guruhlash (rasmiy PDF'da mavzu
  sarlavhalari yo'q), zaif mavzu ⚠️ bilan ko'rsatiladi.
- 🔢 **Raqamli savollar** (164 ta) — javobi raqamga bog'liq: jarima, tezlik, muddat, yosh.
- ⭐ **Saralanganlar** — har savol tagida ⭐; faqat shularni test/yodlash qilish.
- 🔍 **Qidirish** — koreyscha so'z (`어린이 보호구역`), o'zbekcha so'z (lug'at orqali) yoki raqam; sahifalar.
- 🔤 **Lug'at** (305 atama) va savoldagi so'zlarni topuvchi «📚 So'zlar» tugmasi; 🌐 O'zbekcha tarjima.
- 📅 **Imtihon sanasi va reja** — kuniga necha savol kerakligi, tayyorlik foizi (formulasi ekranda yozilgan).
- 🏆 **Do'stlar reytingi** — guruhda `/reyting`, haftalik (dushanba–yakshanba, Koreya vaqti).
- ⏰ **Kunlik eslatma**, 🎯 kunlik maqsad (10/20/30/50/100), 🔥 ketma-ket kunlar.
- 🔒 **Faqat o'zim uchun** (⚙️ Sozlamalar), 👥 `/taklif` havolasi, `/foydalanuvchilar`, `/chiqar ID`, `/yopiq`, `/ochiq`.
- 🔔 **Renew eslatmasi** (Bot-Hosting uchun): ⚙️ Sozlamalar → «Renew eslatmasi» — har 3 kunda egasiga «Renew bosing» deb yozadi.
- 💾 **Zaxira nusxa** (egasi): ⚙️ Sozlamalar → «Zaxira nusxa olish»; kunlik avtomatik zaxira egasiga yuboriladi.
  Tiklash: `.db` faylni botga yuboring, izohiga `/restore` yozing (avval joriy bazadan nusxa olinadi).
  📤 Har foydalanuvchi o'z ma'lumotlarini JSON qilib oladi (Statistika → Eksport). Zaxirada token yo'q.

## Sinov
`python tests/run_tests.py` — soxta Telegram bilan 140 ta tekshiruv (natijalar: `TEST_REPORT.md`).
Haqiqiy Telegramda alohida tekshirilmagan.

## Hali qilinmagan (alohida ish yoki tashqi xizmat kerak)
- 🔊 Koreyscha ovozli o'qish (TTS) — tashqi xizmat va internet kerak.
- 🤖 AI ustoz — API kaliti (.env) va to'lov kerak.
- 📄 PDF eksport — koreys shrifti va PDF kutubxonasi kerak.
- 🚦 Yo'l belgilari bo'limi, 🎥 videoli savollar — PDF'da belgilar to'plami va videolar yo'q
  (video savollarda «홈페이지 참조» deyilgan); soxta material yaratilmaydi.
- Barcha 1000 savolning oldindan tayyor o'zbekcha tarjimasi — hozir savol ochilganda tarjima qilinadi (keshlanadi).

## Fayllar
`main.py` (xosting uchun start), `bot.py` (Telegram), `quiz.py` (savollar, SQLite), `access.py`, `topics.py`, `search.py`, `plan.py`,
`leaderboard.py`, `backup.py`, `glossary.py`, `translate.py`, `questions.json`, `images/`,
`.env.example`, `requirements.txt`, `tests/`.
