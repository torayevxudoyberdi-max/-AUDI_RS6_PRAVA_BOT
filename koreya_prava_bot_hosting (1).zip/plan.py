# -*- coding: utf-8 -*-
"""Imtihon sanasi, kunlik reja va tayyorlik foizi."""
import math
import re
import time
from datetime import date, datetime, timedelta

import quiz
from quiz import TOTAL

LEVELS = [(40, "Boshlang'ich tayyorgarlik"), (65, "Yaxshilanmoqda"),
          (85, "Yaxshi tayyorlangan"), (101, "Yuqori daraja")]


def today_of(tz: int, now: float = None) -> date:
    return datetime.utcfromtimestamp((now or time.time()) + tz * 3600).date()


def parse_date(text: str, today: date):
    """15.12.2026 | 15/12/2026 | 2026-12-15 | 15.12 (shu yil, o'tgan bo'lsa — keyingi yil)"""
    t = text.strip()
    for pat in (r"^(\d{4})-(\d{1,2})-(\d{1,2})$", r"^(\d{1,2})[./](\d{1,2})[./](\d{4})$"):
        m = re.match(pat, t)
        if m:
            a, b, c = (int(x) for x in m.groups())
            y, mo, d = (a, b, c) if a > 31 else (c, b, a)
            try:
                return date(y, mo, d)
            except ValueError:
                return None
    m = re.match(r"^(\d{1,2})[./](\d{1,2})$", t)
    if m:
        d, mo = int(m.group(1)), int(m.group(2))
        try:
            cand = date(today.year, mo, d)
            return cand if cand >= today else date(today.year + 1, mo, d)
        except ValueError:
            return None
    return None


def fmt(d: date) -> str:
    return d.strftime("%d.%m.%Y")


def readiness(uid: int) -> dict:
    """Tayyorlik foizi = qamrov, hozirgi to'g'rilik va sinov imtihonlari natijasidan."""
    st = quiz.user_stats(uid)
    unique, wrong_now = st["unique"], st["wrong_now"]
    coverage = unique / TOTAL
    accuracy = (unique - wrong_now) / unique if unique else 0.0
    exams = [e[1] / e[2] for e in st["exams"][:3]]
    if exams:
        exam = sum(exams) / len(exams)
        pct = 100 * (0.35 * coverage + 0.35 * accuracy + 0.30 * exam)
    else:
        exam = None
        pct = 100 * (0.5 * coverage + 0.5 * accuracy)
    level = next(name for lim, name in LEVELS if pct < lim)
    return dict(pct=pct, level=level, coverage=coverage, accuracy=accuracy, exam=exam,
                unique=unique, wrong_now=wrong_now, n_exams=len(exams))


def make_plan(uid: int, now: float = None) -> dict:
    now = now or time.time()
    s = quiz.get_settings(uid)
    if not s["exam_date"]:
        return dict(has_date=False)
    today = today_of(s["tz"], now)
    exam = date.fromisoformat(s["exam_date"])
    days_left = (exam - today).days
    p = quiz.progress(uid, now)
    st = quiz.user_stats(uid)
    unseen = TOTAL - st["unique"]
    if days_left <= 0:
        return dict(has_date=True, days_left=days_left, exam=exam, unseen=unseen, **p)
    reserve = 2 if days_left > 4 else 0              # oxirgi kunlar — faqat takrorlash
    study_days = max(1, days_left - reserve)
    new_per_day = math.ceil(unseen / study_days)
    review = st["wrong_now"] + p["due"]
    review_per_day = min(30, math.ceil(review / max(1, days_left)))
    rec = max(10, new_per_day + review_per_day)
    return dict(has_date=True, days_left=days_left, exam=exam, unseen=unseen, new_per_day=new_per_day,
                review_per_day=review_per_day, recommended=rec, **p)


def nearest_goal(rec: int, goals: list) -> int:
    return next((g for g in goals if g >= rec), goals[-1])


def quick_date(days: int, tz: int) -> date:
    return today_of(tz) + timedelta(days=days)
