# -*- coding: utf-8 -*-
"""Kirish nazorati: bot egasi, ruxsat berilgan foydalanuvchilar, yopiq rejim."""
import os

import quiz


def _env_ids() -> set:
    raw = os.environ.get("OWNER_ID") or os.environ.get("ADMIN_IDS") or ""
    return {int(x) for x in raw.replace(";", ",").split(",") if x.strip().lstrip("-").isdigit()}


def owner_ids() -> set:
    ids = _env_ids()
    db_owner = quiz.get_bs("owner")
    if db_owner and db_owner.isdigit():
        ids.add(int(db_owner))
    return ids


def claim(uid: int) -> bool:
    """Egasi hali yo'q bo'lsa, birinchi /start bosgan odam ega bo'ladi."""
    if owner_ids():
        return False
    quiz.set_bs("owner", uid)
    quiz.set_bs("private", "1")
    return True


def is_owner(uid: int) -> bool:
    return uid in owner_ids()


def private_mode() -> bool:
    return quiz.get_bs("private", "1") == "1"


def set_private(flag: bool) -> None:
    quiz.set_bs("private", "1" if flag else "0")


def is_allowed(uid: int) -> bool:
    return is_owner(uid) or (not private_mode()) or quiz.is_allowed_db(uid)
