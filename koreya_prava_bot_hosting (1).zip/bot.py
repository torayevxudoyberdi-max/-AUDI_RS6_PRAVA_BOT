# -*- coding: utf-8 -*-
"""Koreya haydovchilik guvohnomasi (1·2-tur) nazariy imtihoni — Telegram bot.

Ishga tushirish:
    export BOT_TOKEN="123456:ABC..."   # yoki TELEGRAM_BOT_TOKEN
    python bot.py
"""
import asyncio
import io
import json
import logging
import os
import random
import time
from datetime import date

from telegram import InlineKeyboardButton as Btn
from telegram import InlineKeyboardMarkup as Markup
from telegram import InputMediaPhoto, Update
from telegram.constants import ParseMode
from telegram.error import BadRequest, TelegramError
from telegram.ext import (
    Application,
    CallbackQueryHandler,
    CommandHandler,
    ContextTypes,
    MessageHandler,
    PersistenceInput,
    PicklePersistence,
    filters,
)

import access
import backup
import glossary
import leaderboard
import plan
import quiz
import search
import topics
import translate
from quiz import ALL_IDS, CIRCLED, IMG_DIR, QUESTIONS, TOTAL, esc

def load_env() -> None:
    """.env faylidan sozlamalarni o'qiydi (bor muhit o'zgaruvchilarini bosib o'tmaydi)."""
    f = quiz.BASE / ".env"
    if not f.exists():
        return
    for line in f.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            k, v = line.split("=", 1)
            os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


load_env()
logging.basicConfig(
    format="%(asctime)s %(levelname)s %(name)s: %(message)s", level=logging.INFO
)
log = logging.getLogger("hayduvchi-bot")
HTML = ParseMode.HTML
RENEW_DAYS = int(os.environ.get("RENEW_DAYS", "3"))   # Bot-Hosting: har 4 kunda Renew kerak
_TASKS = set()          # fon vazifalariga havola (garbage collection'dan saqlash)

# ------------------------------------------------------------ file_id keshi
CACHE_FILE = quiz.DATA_DIR / "file_ids.json"
try:
    FILE_IDS = json.loads(CACHE_FILE.read_text(encoding="utf-8"))
except Exception:
    FILE_IDS = {}


def _save_cache() -> None:
    try:
        CACHE_FILE.write_text(json.dumps(FILE_IDS), encoding="utf-8")
    except OSError:
        log.warning("file_ids.json yozib bo'lmadi")


async def send_images(bot, chat_id: int, names: list) -> None:
    """Savolga tegishli rasm(lar)ni yuboradi. Birinchi marta fayldan, keyin file_id orqali."""
    for attempt in (0, 1):
        use_cache = attempt == 0
        srcs = [(FILE_IDS.get(n) if use_cache else None) or (IMG_DIR / n) for n in names]
        try:
            if len(srcs) == 1:
                msgs = [await bot.send_photo(chat_id, srcs[0])]
            else:
                msgs = await bot.send_media_group(chat_id, [InputMediaPhoto(s) for s in srcs])
            for n, m in zip(names, msgs):
                FILE_IDS[n] = m.photo[-1].file_id
            _save_cache()
            return
        except BadRequest:
            if attempt == 1:
                raise
            for n in names:           # file_id eskirgan bo'lishi mumkin
                FILE_IDS.pop(n, None)


# ------------------------------------------------------------ klaviaturalar
def menu_kb(due: int = 0, saved_n: int = 0) -> Markup:
    return Markup([
        [Btn("📖 Yodlash rejimi (javob ko'rsatilgan)", callback_data="stm")],
        [Btn("🎯 Tasodifiy mashq", callback_data="pr"),
         Btn(f"🔁 Takrorlash ({due})" if due else "🔁 Takrorlash", callback_data="srs")],
        [Btn("📝 Imtihon · 1-tur", callback_data="ex:1"),
         Btn("📝 Imtihon · 2-tur", callback_data="ex:2")],
        [Btn("🧩 Mavzular", callback_data="tp"),
         Btn("🔢 Raqamli savollar", callback_data="nm")],
        [Btn(f"⭐ Saralanganlar ({saved_n})" if saved_n else "⭐ Saralanganlar", callback_data="svm"),
         Btn("❌ Xatolarim", callback_data="wr")],
        [Btn("🔍 Qidirish", callback_data="qs"),
         Btn("🔤 Lug'at", callback_data="lex")],
        [Btn("📅 Reja", callback_data="pl"),
         Btn("📊 Statistika", callback_data="st")],
        [Btn("🏆 Reyting", callback_data="lbp"),
         Btn("⚙️ Sozlamalar", callback_data="set")],
        [Btn("📂 Boshqa mashqlar", callback_data="menu2")],
    ])


def aid_row(q: dict, reveal: bool, uid=None) -> list:
    """Tarjima, lug'at va ⭐ saqlash tugmalari."""
    r = int(reveal)
    row = [Btn("🌐 O'zbekcha", callback_data=f"tr:{q['id']}:{r}")]
    n = len(glossary.terms_for(q, with_expl=reveal))
    if n:
        row.append(Btn(f"📚 So'zlar ({n})", callback_data=f"tm:{q['id']}:{r}"))
    if uid is not None:
        row.append(Btn("★" if quiz.is_saved(uid, q["id"]) else "⭐", callback_data=f"sv:{q['id']}"))
    return row


def card_kb(s: dict, q: dict, revealed: bool) -> Markup:
    uid = s.get("uid")
    if not revealed:
        return Markup([[Btn("👁 Javobni ko'rish", callback_data="fcv")],
                       aid_row(q, False, uid), [Btn("🏠 Menyu", callback_data="menu")]])
    return Markup([[Btn("✅ Bilaman", callback_data="fck:1"), Btn("🔁 Yana takrorlash", callback_data="fck:0")],
                   aid_row(q, True, uid), [Btn("🏠 Menyu", callback_data="menu")]])


def fast_btn(s: dict) -> list:
    return [Btn("⚡ Tez rejim: " + ("✅ yoqilgan" if s.get("fast") else "❌ o'chirilgan"),
                callback_data="fast:tg")]


def question_kb(s: dict, q: dict, reveal: bool = False) -> Markup:
    rows = []
    if not reveal:
        chosen = s["chosen"]
        rows.append([
            Btn(("✅ " if i in chosen else "") + CIRCLED[i - 1], callback_data=f"a:{q['id']}:{i}")
            for i in range(1, len(q["o"]) + 1)
        ])
        if len(q["a"]) > 1 and len(chosen) == len(q["a"]):
            rows.append([Btn("✔️ Tasdiqlash", callback_data=f"ok:{q['id']}")])
        if s["mode"] == "exam":
            rows.append(aid_row(q, False))
            rows.append([Btn("🏁 Imtihonni tugatish", callback_data="fin")])
        else:
            rows.append(aid_row(q, False, s.get("uid")))
            rows.append(fast_btn(s))
            rows.append([Btn("⏭ O'tkazib yuborish", callback_data="nx"),
                         Btn("🏠 Menyu", callback_data="menu")])
    else:
        rows.append(aid_row(q, True, s.get("uid")))
        if s["mode"] != "exam":
            rows.append(fast_btn(s))
        rows.append([Btn("➡️ Keyingi savol", callback_data="nx")])
        rows.append([Btn("🏠 Menyu", callback_data="menu")])
    return Markup(rows)


def study_kb(s: dict, q: dict) -> Markup:
    nav = []
    if s["i"] > 0:
        nav.append(Btn("⬅️ Oldingi", callback_data="sp"))
    if s["i"] < len(s["queue"]) - 1:
        nav.append(Btn("Keyingi ➡️", callback_data="sn"))
    rows = ([nav] if nav else []) + [aid_row(q, True, s.get("uid")), [Btn("🏠 Menyu", callback_data="menu")]]
    return Markup(rows)


# ------------------------------------------------------------ yordamchilar
def sess(ctx):
    return ctx.user_data.get("s")


def exam_left(s: dict) -> float:
    return quiz.EXAM_SECONDS - (time.time() - s["t0"])


def fmt_left(sec: float) -> str:
    sec = max(0, int(sec))
    return f"{sec // 60:02d}:{sec % 60:02d}"


def header_for(s: dict) -> str:
    if s["mode"] == "exam":
        return f"[{s['i'] + 1}/{len(s['queue'])}] ⏱{fmt_left(exam_left(s))} "
    if s["mode"] in ("wrong", "img", "blk", "study", "srs", "num", "saved", "topic", "card"):
        return f"[{s['i'] + 1}/{len(s['queue'])}] "
    return ""


async def safe_edit(query, text: str, markup=None) -> None:
    try:
        await query.edit_message_text(text, parse_mode=HTML, reply_markup=markup)
    except BadRequest as e:
        if "not modified" not in str(e).lower():
            raise


async def strip_kb(query) -> None:
    try:
        await query.edit_message_reply_markup(reply_markup=None)
    except TelegramError:
        pass


async def send_menu(bot, chat_id: int) -> None:
    p = quiz.progress(chat_id)           # shaxsiy chatda chat_id == user_id
    st = quiz.get_settings(chat_id)
    lines = [
        "🚗 <b>Koreya haydovchilik guvohnomasi — nazariy imtihon</b>",
        f"1·2-tur savollar banki (2026.3.9 dan amalda): <b>{TOTAL}</b> ta savol, "
        f"shundan <b>{len(quiz.IMAGE_IDS)}</b> tasi rasmli.",
        "",
        f"🔥 Ketma-ket: <b>{p['streak']}</b> kun  ·  Bugun: <b>{p['n']}/{p['goal']}</b>",
    ]
    if st["exam_date"]:
        left = (date.fromisoformat(st["exam_date"]) - plan.today_of(st["tz"])).days
        if left >= 0:
            lines.append(f"📅 Imtihongacha: <b>{left}</b> kun")
    if p["due"]:
        lines.append(f"🔁 Takrorlash uchun tayyor: <b>{p['due']}</b> ta savol")
    lines += [
        "",
        "📖 Yodlash: to'g'ri javob <u>tagiga chiziq</u> bilan, kalit raqam va so'zlar "
        "<b>qalin</b> shriftda ko'rsatiladi. ⭐ — savolni saralanganlarga saqlash.",
        "",
        "Rejimni tanlang 👇",
    ]
    await bot.send_message(
        chat_id, "\n".join(lines), parse_mode=HTML,
        reply_markup=menu_kb(p["due"], len(quiz.saved_ids(chat_id))),
    )


# ------------------------------------------------------------ sessiya
async def exam_timer(ctx, chat_id: int, uid: int, t0: float) -> None:
    """5 daqiqa qolganda ogohlantiradi, vaqt tugaganda imtihonni o'zi yakunlaydi."""
    def active():
        s = ctx.user_data.get("s")
        return bool(s and s.get("mode") == "exam" and s.get("t0") == t0)

    try:
        await asyncio.sleep(max(0, t0 + quiz.EXAM_SECONDS - 300 - time.time()))
        if not active():
            return
        await ctx.bot.send_message(chat_id, "⏱ <b>5 daqiqa qoldi!</b>", parse_mode=HTML)
        await asyncio.sleep(max(0, t0 + quiz.EXAM_SECONDS - time.time()))
        if not active():
            return
        await finish_exam(ctx, chat_id, uid, timeout=True)
    except asyncio.CancelledError:
        raise
    except Exception:
        log.exception("imtihon taymeri xatosi")


async def start_session(ctx, chat_id: int, mode: str, queue: list, **extra) -> None:
    if not queue:
        await ctx.bot.send_message(chat_id, "Savollar topilmadi.")
        return
    s = dict(mode=mode, queue=list(queue), i=0, chosen=[], done=False, answers={},
             t0=time.time(), uid=ctx.user_data.get("uid"), fast=False)
    s.update(extra)
    ctx.user_data["await_search"] = False
    ctx.user_data["await_date"] = False
    if mode != "exam" and s["uid"] is not None:
        s["fast"] = quiz.get_settings(s["uid"])["fast"]
    ctx.user_data["s"] = s
    await show_current(ctx, chat_id)
    if mode == "exam":
        s = sess(ctx)
        task = asyncio.create_task(exam_timer(ctx, chat_id, s["uid"], s["t0"]))
        _TASKS.add(task)
        task.add_done_callback(_TASKS.discard)


async def show_current(ctx, chat_id: int) -> None:
    s = sess(ctx)
    q = QUESTIONS[s["queue"][s["i"]]]
    s["chosen"], s["done"] = [], False
    if q["img"]:
        await send_images(ctx.bot, chat_id, q["img"])
    if s["mode"] == "card":
        s["revealed"] = False
        await ctx.bot.send_message(
            chat_id, quiz.format_question(q, header=header_for(s), card=True), parse_mode=HTML,
            reply_markup=card_kb(s, q, False),
        )
        return
    if s["mode"] == "study":
        await ctx.bot.send_message(
            chat_id,
            quiz.format_question(q, reveal=True, header=header_for(s)),
            parse_mode=HTML,
            reply_markup=study_kb(s, q),
        )
        return
    await ctx.bot.send_message(
        chat_id,
        quiz.format_question(q, header=header_for(s)),
        parse_mode=HTML,
        reply_markup=question_kb(s, q),
    )


async def advance(ctx, chat_id: int) -> None:
    s = sess(ctx)
    s["i"] += 1
    if s["i"] >= len(s["queue"]):
        if s["mode"] == "exam":
            await finish_exam(ctx, chat_id, s["uid"])
        else:
            ctx.user_data["s"] = None
            if s["mode"] == "card":
                await ctx.bot.send_message(
                    chat_id, f"🃏 <b>Flashcard sessiyasi tugadi!</b>\n✅ Bilaman: {s.get('known', 0)}  ·  "
                    f"🔁 Yana takrorlash: {s.get('again', 0)}\n"
                    "<i>Bilmagan kartalar tez orada, bilganlari esa 1–30 kundan keyin qaytadi.</i>",
                    parse_mode=HTML)
            else:
                await ctx.bot.send_message(chat_id, "✅ Savollar tugadi!")
            await send_menu(ctx.bot, chat_id)
        return
    await show_current(ctx, chat_id)


async def finish_exam(ctx, chat_id: int, uid: int, timeout: bool = False) -> None:
    s = sess(ctx)
    if not s or s["mode"] != "exam":
        return
    queue, answers = s["queue"], s["answers"]
    wrong = [
        qid for qid in queue
        if str(qid) not in answers or not quiz.is_correct(QUESTIONS[qid], answers[str(qid)])
    ]
    correct = len(queue) - len(wrong)
    score = correct * 100 / len(queue)
    need = quiz.PASS_SCORE[s["cls"]]
    secs = min(int(time.time() - s["t0"]), quiz.EXAM_SECONDS)
    quiz.save_exam(uid, s["cls"], correct, len(queue), secs)

    ctx.user_data["review"] = wrong
    ctx.user_data["review_ans"] = answers
    ctx.user_data["s"] = None

    verdict = "✅ <b>O'TDINGIZ!</b>" if score >= need else "❌ <b>O'tolmadingiz</b>"
    text = (
        f"🏁 <b>Imtihon yakunlandi ({s['cls']}-tur)</b>\n"
        + ("⏰ <i>Vaqt tugadi — javob berilmaganlar xato hisoblandi.</i>\n" if timeout else "")
        + f"\nTo'g'ri javoblar: <b>{correct} / {len(queue)}</b>\n"
        f"Ball: <b>{score:.1f}</b> / 100  (o'tish bali: {need})\n"
        f"{verdict}\n"
        f"⏱ Vaqt: {secs // 60} daq {secs % 60} son  (imtihon vaqti 40 daqiqa)\n\n"
        "<i>Eslatma: haqiqiy imtihonda savollar 2–5 ball turlicha baholanadi; "
        "bu yerda har bir savol teng (2,5 ball) hisoblanadi.</i>"
    )
    rows = []
    if wrong:
        rows.append([Btn(f"❌ Xatolarni ko'rish ({len(wrong)})", callback_data="rv:0")])
    rows.append([Btn("🏠 Menyu", callback_data="menu")])
    await ctx.bot.send_message(chat_id, text, parse_mode=HTML, reply_markup=Markup(rows))


async def show_review(ctx, chat_id: int, k: int) -> None:
    wrong = ctx.user_data.get("review") or []
    if not wrong:
        await send_menu(ctx.bot, chat_id)
        return
    k = max(0, min(k, len(wrong) - 1))
    q = QUESTIONS[wrong[k]]
    chosen = (ctx.user_data.get("review_ans") or {}).get(str(q["id"]), [])
    if q["img"]:
        await send_images(ctx.bot, chat_id, q["img"])
    nav = []
    if k > 0:
        nav.append(Btn("⬅️", callback_data=f"rv:{k - 1}"))
    if k < len(wrong) - 1:
        nav.append(Btn("➡️", callback_data=f"rv:{k + 1}"))
    rows = ([nav] if nav else []) + [aid_row(q, True, ctx.user_data.get("uid")), [Btn("🏠 Menyu", callback_data="menu")]]
    await ctx.bot.send_message(
        chat_id,
        quiz.format_question(q, chosen, reveal=True, result=False, header=f"Xato {k + 1}/{len(wrong)} · "),
        parse_mode=HTML,
        reply_markup=Markup(rows),
    )


async def send_stats(bot, chat_id: int, uid: int) -> None:
    st = quiz.user_stats(uid)
    p = quiz.progress(uid)
    total = st["ok"] + st["bad"]
    acc = f"{st['ok'] * 100 / total:.0f}%" if total else "—"
    lines = [
        "📊 <b>Statistika</b>\n",
        f"Yechilgan savollar: <b>{st['unique']}</b> / {TOTAL}",
        f"To'g'ri: {st['ok']}  ·  Noto'g'ri: {st['bad']}  ·  Aniqlik: {acc}",
        f"Hozir xato holatda: <b>{st['wrong_now']}</b>",
        f"🔥 Ketma-ket: <b>{p['streak']}</b> kun  ·  Bugun: {p['n']}/{p['goal']}",
        f"🔁 Takrorlashda: <b>{p['srs_total']}</b> (hozir tayyor: {p['due']})",
    ]
    rd = plan.readiness(uid)
    lines.append(f"🎯 Tayyorlik: <b>{rd['pct']:.0f}%</b> — {rd['level']} (taxminiy)")
    cs = quiz.card_stats(uid)
    lines.append(f"🃏 Flashcard: o'zlashtirilgan <b>{cs['learned']}</b> · ko'rilgan {cs['total']} · "
                 f"muddati kelgan {cs['due']}")
    if st["exams"]:
        lines.append("\n🏁 <b>Oxirgi imtihonlar:</b>")
        for cls, ok, tot, ts in st["exams"]:
            score = ok * 100 / tot
            mark = "✅" if score >= quiz.PASS_SCORE[cls] else "❌"
            lines.append(f"{time.strftime('%d.%m.%Y', time.localtime(ts))} · {cls}-tur · {ok}/{tot} {mark}")
    await bot.send_message(
        chat_id, "\n".join(lines), parse_mode=HTML,
        reply_markup=Markup([[Btn("📤 Ma'lumotlarimni eksport (JSON)", callback_data="xp")],
                             [Btn("🏠 Menyu", callback_data="menu")]]),
    )


# ------------------------------------------------------------ eslatma sozlamalari
TIMES = [(480, "08:00"), (720, "12:00"), (1080, "18:00"), (1200, "20:00"), (1260, "21:00"), (1320, "22:00")]
GOALS = [10, 20, 30, 50, 100]
ZONES = [(9, "🇰🇷 Koreya"), (5, "🇺🇿 O'zbekiston")]


def settings_view(uid: int):
    st = quiz.get_settings(uid)
    rem = "o'chirilgan 🔕" if st["remind"] is None else f"{st['remind'] // 60:02d}:{st['remind'] % 60:02d}"
    zone = dict(ZONES).get(st["tz"], f"UTC{st['tz']:+d}")
    text = (
        "⚙️ <b>Eslatma va maqsad</b>\n\n"
        f"⏰ Eslatma vaqti: <b>{rem}</b>\n"
        f"🎯 Kunlik maqsad: <b>{st['goal']}</b> savol\n"
        f"🌏 Vaqt zonasi: <b>{zone}</b>\n\n"
        "<i>Eslatma faqat bugungi maqsad bajarilmagan bo'lsa yuboriladi.</i>"
    )
    def t_btn(m, label):
        return Btn(("✅ " if st["remind"] == m else "") + label, callback_data=f"rm:{m}")
    rows = [
        [t_btn(m, l) for m, l in TIMES[:3]],
        [t_btn(m, l) for m, l in TIMES[3:]],
        [Btn(("✅ " if st["remind"] is None else "") + "🔕 O'chirish", callback_data="rm:off")],
        [Btn(("✅ " if st["goal"] == g else "") + f"🎯 {g}", callback_data=f"goal:{g}") for g in GOALS],
        [Btn(("✅ " if st["tz"] == z else "") + l, callback_data=f"tz:{z}") for z, l in ZONES],
        [Btn("⬅️ Sozlamalar", callback_data="set"), Btn("🏠 Menyu", callback_data="menu")],
    ]
    return text, Markup(rows)


def settings_main(uid: int):
    st = quiz.get_settings(uid)
    rem = "o'chiq" if st["remind"] is None else f"{st['remind'] // 60:02d}:{st['remind'] % 60:02d}"
    exam = "belgilanmagan"
    if st["exam_date"]:
        left = (date.fromisoformat(st["exam_date"]) - plan.today_of(st["tz"])).days
        exam = f"{plan.fmt(date.fromisoformat(st['exam_date']))} ({left} kun qoldi)" if left >= 0 else "o'tib ketgan"
    text = (
        "⚙️ <b>Sozlamalar</b>\n\n"
        f"⚡ Tez rejim: <b>{'yoqilgan' if st['fast'] else "o'chirilgan"}</b>\n"
        f"⏰ Eslatma: <b>{rem}</b>  ·  🎯 Maqsad: <b>{st['goal']}</b>\n"
        f"📅 Imtihon sanasi: <b>{exam}</b>"
    )
    rows = [
        [Btn("⏰ Eslatma va maqsad", callback_data="rem")],
        [Btn("⚡ Tez rejim: " + ("✅" if st["fast"] else "❌"), callback_data="fast:st")],
        [Btn("📅 Imtihon sanasi va reja", callback_data="pl")],
    ]
    if access.is_owner(uid):
        text += f"\n🔒 Faqat o'zim uchun: <b>{'yoqilgan' if access.private_mode() else "o'chirilgan"}</b>"
        rows += [
            [Btn("🔒 Faqat o'zim uchun: " + ("✅" if access.private_mode() else "❌"), callback_data="acc:tg")],
            [Btn("👥 Taklif havolasi", callback_data="acc:inv"), Btn("📋 Ruxsatlilar", callback_data="acc:ls")],
            [Btn("💾 Zaxira nusxa olish", callback_data="bk:get"), Btn("♻️ Tiklash", callback_data="bk:help")],
            [Btn("📬 Kunlik zaxirani menga yuborish: " + ("✅" if quiz.get_bs("backup_tg", "1") == "1" else "❌"),
                 callback_data="bk:tg")],
            [Btn(f"🔔 Renew eslatmasi ({RENEW_DAYS} kunda bir): "
                 + ("✅" if quiz.get_bs("renew_remind", "0") == "1" else "❌"), callback_data="rn:tg")],
        ]
    rows.append([Btn("🏠 Menyu", callback_data="menu")])
    return text, Markup(rows)


async def reminder_loop(app: Application) -> None:
    """Har 30 soniyada eslatma vaqti kelgan foydalanuvchilarni tekshiradi."""
    while True:
        try:
            await asyncio.sleep(30)
            try:                                   # kunlik avtomatik zaxira (egasiga yuboriladi)
                path = await asyncio.to_thread(backup.auto_backup_if_due)
                if path and quiz.get_bs("backup_tg", "1") == "1":
                    for oid in access.owner_ids():
                        try:
                            await app.bot.send_document(oid, document=path, filename=path.name,
                                                        caption="💾 Kunlik zaxira nusxa")
                        except TelegramError as e:
                            log.warning("zaxira yuborilmadi (%s): %s", oid, e)
            except Exception:
                log.exception("avto-zaxira xatosi")
            try:                                   # Bot-Hosting «Renew» eslatmasi (egasiga)
                if quiz.get_bs("renew_remind", "0") == "1":
                    last = float(quiz.get_bs("renew_last", "0") or 0)
                    if time.time() - last >= RENEW_DAYS * 86400:
                        quiz.set_bs("renew_last", time.time())
                        for oid in access.owner_ids():
                            try:
                                await app.bot.send_message(
                                    oid,
                                    "⏳ <b>Renew vaqti!</b>\nBot-Hosting panelida botingiz sahifasida "
                                    "<b>Renew</b> tugmasini bosing, aks holda bot 4 kundan keyin to'xtaydi.\n"
                                    f"<i>Keyingi eslatma {RENEW_DAYS} kundan keyin.</i>", parse_mode=HTML)
                            except TelegramError as e:
                                log.warning("renew eslatmasi yuborilmadi (%s): %s", oid, e)
            except Exception:
                log.exception("renew eslatmasi xatosi")
            for r in quiz.users_to_remind():
                text = (
                    f"⏰ <b>Eslatma!</b> Bugun {r['n']}/{r['goal']} savol yechdingiz.\n"
                    f"🔥 Ketma-ket: {r['streak']} kun"
                )
                rows = []
                if r.get("exam_date"):
                    left = (date.fromisoformat(r["exam_date"]) - date.fromisoformat(r["today"])).days
                    if left >= 0:
                        text += f"\n📅 Imtihongacha: {left} kun"
                if r["due"]:
                    text += f"\n🔁 Takrorlash uchun tayyor: {r['due']} ta"
                    rows.append([Btn(f"🔁 Takrorlash ({r['due']})", callback_data="srs")])
                rows.append([Btn("🎯 Mashq", callback_data="pr"), Btn("📖 Yodlash", callback_data="stm")])
                rows.append([Btn("🏠 Menyu", callback_data="menu")])
                try:
                    await app.bot.send_message(r["uid"], text, parse_mode=HTML, reply_markup=Markup(rows))
                except TelegramError as e:
                    log.warning("eslatma yuborilmadi (%s): %s", r["uid"], e)
        except asyncio.CancelledError:
            raise
        except Exception:
            log.exception("eslatma sikli xatosi")


# ------------------------------------------------------------ javob berish
async def finalize(ctx, query, s: dict, q: dict) -> None:
    chosen = sorted(s["chosen"])
    ok = quiz.is_correct(q, chosen)
    s["answers"][str(q["id"])] = chosen
    s["done"] = True
    info = quiz.record_answer(query.from_user.id, q["id"], ok)
    chat_id = query.message.chat_id
    if s["mode"] == "exam":
        await safe_edit(query, f"<b>№ {q['id']}</b> — javobingiz: {quiz.letters(chosen)}")
        await advance(ctx, chat_id)
    elif s.get("fast") and ok and s["mode"] != "study":
        # ⚡ Tez rejim: to'g'ri javobda tugmasiz keyingi savolga o'tadi
        await safe_edit(
            query, quiz.format_question(q, chosen, reveal=True, result=True, header=header_for(s)), None
        )
        if info["just_met"]:
            await ctx.bot.send_message(
                chat_id,
                f"🎉 <b>Kunlik maqsad bajarildi!</b> ({info['goal']} savol)\n"
                f"🔥 Ketma-ket: <b>{info['streak']}</b> kun",
                parse_mode=HTML,
            )
        await asyncio.sleep(0.9)
        if sess(ctx) is s:
            await advance(ctx, chat_id)
    else:
        await safe_edit(
            query,
            quiz.format_question(q, chosen, reveal=True, result=ok, header=header_for(s)),
            question_kb(s, q, reveal=True),
        )
        if info["just_met"]:
            await ctx.bot.send_message(
                chat_id,
                f"🎉 <b>Kunlik maqsad bajarildi!</b> ({info['goal']} savol)\n"
                f"🔥 Ketma-ket: <b>{info['streak']}</b> kun",
                parse_mode=HTML,
            )


async def handle_option(ctx, query, qid: int, i: int):
    s = sess(ctx)
    if not s or s["done"] or s["queue"][s["i"]] != qid:
        return "Bu savol allaqachon yopilgan."
    q = QUESTIONS[qid]
    need = len(q["a"])
    if need == 1:
        s["chosen"] = [i]
        await finalize(ctx, query, s, q)
        return None
    chosen = s["chosen"]
    if i in chosen:
        chosen.remove(i)
    elif len(chosen) < need:
        chosen.append(i)
    else:
        return f"Faqat {need} ta javob tanlanadi — avval birini bekor qiling."
    await safe_edit(
        query,
        quiz.format_question(q, chosen, header=header_for(s)),
        question_kb(s, q),
    )
    return None


# ------------------------------------------------------------ callback router
def block_rows(prefix: str) -> list:
    rows, row = [], []
    for st in range(1, TOTAL + 1, quiz.BLOCK):
        row.append(Btn(f"{st}–{min(st + quiz.BLOCK - 1, TOTAL)}", callback_data=f"{prefix}:{st}"))
        if len(row) == 3:
            rows.append(row)
            row = []
    if row:
        rows.append(row)
    return rows



# ------------------------------------------------------------ yangi bo'limlar: yordamchilar
def ids_for(key: str, uid: int) -> list:
    if key == "num":
        return topics.NUMERIC_IDS[:]
    if key == "saved":
        return quiz.saved_ids(uid)
    if key == "img":
        return quiz.IMAGE_IDS[:]
    if key == "wrong":
        return quiz.wrong_ids(uid)
    if key.startswith("t_"):
        return topics.ids_of(key[2:])
    return []


async def send_choose(ctx, chat_id: int, title: str, key: str, count: int,
                      extra_rows=None, note: str = "") -> None:
    rows = [[Btn("🎯 Test (aralash)", callback_data=f"go:{key}:t")],
            [Btn("📖 Yodlash (javob bilan)", callback_data=f"go:{key}:s")]]
    rows += extra_rows or []
    rows.append([Btn("🏠 Menyu", callback_data="menu")])
    await ctx.bot.send_message(
        chat_id, f"<b>{esc(title)}</b>\n{count} ta savol.{note}", parse_mode=HTML,
        reply_markup=Markup(rows),
    )


SR_PER = 6


def search_view(sr: dict, page: int):
    ids = sr["ids"]
    pages = max(1, (len(ids) + SR_PER - 1) // SR_PER)
    page = max(0, min(page, pages - 1))
    sr["page"] = page
    head = f"🔍 <b>{esc(sr['q'])}</b> — <b>{len(ids)}</b> ta savol topildi"
    if sr.get("terms"):
        head += "\n<i>Lug'at orqali: " + ", ".join(esc(t) for t in sr["terms"]) + "</i>"
    head += f"\nSahifa {page + 1}/{pages}"
    rows = [[Btn(f"№{i} · {search.snippet(i)}", callback_data=f"qv:{i}")]
            for i in ids[page * SR_PER:(page + 1) * SR_PER]]
    nav = []
    if page > 0:
        nav.append(Btn("⬅️", callback_data=f"qp:{page - 1}"))
    if page < pages - 1:
        nav.append(Btn("➡️", callback_data=f"qp:{page + 1}"))
    if nav:
        rows.append(nav)
    rows.append([Btn("🔍 Yangi qidiruv", callback_data="qs"), Btn("🏠 Menyu", callback_data="menu")])
    return head, Markup(rows)


async def do_search(ctx, chat_id: int, text: str) -> None:
    res = search.search(text)
    if not res["ids"]:
        await ctx.bot.send_message(
            chat_id,
            f"«{text}» bo'yicha savol topilmadi.\nBoshqa so'z yuboring (masalan: 어린이 보호구역, 과태료, 교차로).",
        )
        return
    ctx.user_data["sr"] = dict(q=text, ids=res["ids"], terms=res["terms"], page=0)
    head, kb = search_view(ctx.user_data["sr"], 0)
    await ctx.bot.send_message(chat_id, head, parse_mode=HTML, reply_markup=kb)


async def show_question_detail(ctx, chat_id: int, qid: int, back_page=None) -> None:
    q = QUESTIONS[qid]
    if q["img"]:
        await send_images(ctx.bot, chat_id, q["img"])
    rows = [aid_row(q, True, ctx.user_data.get("uid"))]
    if back_page is not None:
        rows.append([Btn("⬅️ Natijalar", callback_data=f"qp:{back_page}")])
    rows.append([Btn("🏠 Menyu", callback_data="menu")])
    await ctx.bot.send_message(
        chat_id, quiz.format_question(q, reveal=True, header="🔍 "), parse_mode=HTML,
        reply_markup=Markup(rows),
    )


async def send_topics(ctx, chat_id: int, uid: int) -> None:
    st = topics.stats(uid)
    rated = [r for r in st if r[0] != "other" and (r[3] + r[4]) >= 5]
    weak = min(rated, key=lambda r: r[5])[0] if rated else None
    lines = ["🧩 <b>Mavzular bo'yicha mashq</b>",
             "<i>Mavzular kalit so'zlar bo'yicha avtomatik aniqlanadi — rasmiy PDF bankida mavzu "
             "sarlavhalari yo'q.</i>", ""]
    rows = []
    for key, total, solved, ok, bad, acc in st:
        if not total:
            continue
        t = topics.BY_KEY[key]
        acc_s = f"{acc:.0f}%" if acc is not None else "—"
        lines.append(f"{t[1]} {esc(t[2])}: {solved}/{total} · aniqlik {acc_s}" + (" ⚠️" if key == weak else ""))
        rows.append([Btn(f"{t[1]} {t[2]} ({total})", callback_data=f"tp:{key}")])
    if weak:
        lines += ["", f"⚠️ Eng zaif mavzu: <b>{esc(topics.label(weak))}</b>"]
        rows.insert(0, [Btn(f"⚠️ Eng zaif: {topics.label(weak)}", callback_data=f"tp:{weak}")])
    else:
        lines += ["", "<i>Zaif mavzuni aniqlash uchun har mavzuda kamida 5 ta javob kerak.</i>"]
        rows.insert(0, [Btn("🎲 Eng kam yechilgan mavzu", callback_data="tpw")])
    rows.append([Btn("🏠 Menyu", callback_data="menu")])
    await ctx.bot.send_message(chat_id, "\n".join(lines), parse_mode=HTML, reply_markup=Markup(rows))


def bar(pct: float, n: int = 10) -> str:
    k = max(0, min(n, round(pct / 100 * n)))
    return "▰" * k + "▱" * (n - k)


def plan_view(uid: int):
    r = plan.readiness(uid)
    pl = plan.make_plan(uid)
    lines = ["📅 <b>Imtihon rejasi va tayyorlik</b>", ""]
    if pl["has_date"]:
        if pl["days_left"] > 0:
            lines.append(f"Imtihon: <b>{plan.fmt(pl['exam'])}</b> — <b>{pl['days_left']}</b> kun qoldi")
        elif pl["days_left"] == 0:
            lines.append("Imtihon <b>bugun</b>! Omad tilayman! 🍀")
        else:
            lines.append("Belgilangan sana o'tib ketgan — yangi sana kiriting.")
    else:
        lines.append("Imtihon sanasi hali kiritilmagan.")
    lines += ["", f"🎯 Tayyorlik: <b>{r['pct']:.0f}%</b> {bar(r['pct'])}", f"<b>{r['level']}</b>",
              f"• Qamrov: {r['unique']}/{TOTAL} savol ({r['coverage'] * 100:.0f}%)",
              f"• Hozirgi to'g'rilik: {r['accuracy'] * 100:.0f}% (xato holatda: {r['wrong_now']})"]
    if r["exam"] is not None:
        lines.append(f"• Sinov imtihonlari: o'rtacha {r['exam'] * 100:.0f}% (oxirgi {r['n_exams']} ta)")
    else:
        lines.append("• Sinov imtihoni hali yo'q (📝 Imtihon rejimini sinab ko'ring)")
    rows = []
    if pl["has_date"] and pl["days_left"] > 0:
        lines += ["", f"📌 <b>Reja: kuniga ~{pl['recommended']} savol</b>",
                  f"   yangi ~{pl['new_per_day']} + takrorlash ~{pl['review_per_day']} "
                  f"(hali yechilmagan: {pl['unseen']} ta)",
                  f"   Bugun: {pl['n']}/{pl['goal']} (kunlik maqsad)"]
        g = plan.nearest_goal(pl["recommended"], GOALS)
        if g != pl["goal"]:
            rows.append([Btn(f"🎯 Kunlik maqsadni {g} qilish", callback_data=f"pg:{g}")])
    lines += ["", "<i>Hisoblash: tayyorlik = 35% qamrov + 35% to'g'rilik + 30% sinov imtihonlari "
              "(sinov bo'lmasa 50% + 50%). Bu taxminiy baho — rasmiy imtihondan o'tishni "
              "kafolatlamaydi.</i>"]
    if pl["has_date"]:
        rows.append([Btn("📅 Sanani o'zgartirish", callback_data="pc"), Btn("🗑 Sanani o'chirish", callback_data="px")])
    else:
        rows += [[Btn("1 hafta", callback_data="pd:7"), Btn("2 hafta", callback_data="pd:14"),
                  Btn("1 oy", callback_data="pd:30"), Btn("2 oy", callback_data="pd:60")],
                 [Btn("✍️ Sanani yozish", callback_data="pc")]]
    rows.append([Btn("🏠 Menyu", callback_data="menu")])
    return "\n".join(lines), Markup(rows)


def lb_kb() -> Markup:
    return Markup([[Btn("➕ Qo'shilish", callback_data="lb:j"), Btn("🔄 Yangilash", callback_data="lb:r")],
                   [Btn("🚪 Chiqish", callback_data="lb:l")]])


async def send_lb_private(ctx, chat_id: int, uid: int) -> None:
    lines = ["🏆 <b>Do'stlar reytingi</b>", "",
             "1. Botni guruhingizga qo'shing.", "2. Guruhda <code>/reyting</code> yuboring.",
             "3. «➕ Qo'shilish» ni bosing — har kim o'z natijasi bilan qatnashadi.",
             "Ball — shu hafta (dushanba–yakshanba, Koreya vaqti) berilgan to'g'ri javoblar soni.", ""]
    groups = quiz.lb_groups_of(uid)
    if groups:
        for gid, title in groups:
            rows = leaderboard.ranking(gid)
            rank = next((i + 1 for i, r in enumerate(rows) if r[4] == uid), None)
            if rank:
                lines.append(f"• {esc(title or 'Guruh')}: <b>{rank}-o'rin</b> ({rows[rank - 1][0]} ta to'g'ri)")
    else:
        lines.append("Siz hali hech qaysi reytingga qo'shilmagansiz.")
    if access.private_mode():
        lines += ["", "🔒 Bot hozir yopiq rejimda: do'stlaringiz ishlata olishi uchun "
                  + ("/taklif orqali taklif havolasini yuboring." if access.is_owner(uid)
                     else "bot egasidan taklif havolasi so'rang.")]
    await ctx.bot.send_message(chat_id, "\n".join(lines), parse_mode=HTML,
                               reply_markup=Markup([[Btn("🏠 Menyu", callback_data="menu")]]))


async def toggle_saved_btn(query, uid: int, qid: int) -> str:
    now_saved = quiz.toggle_saved(uid, qid)
    kb = getattr(query.message, "reply_markup", None)
    if kb is not None:
        rows = []
        for row in kb.inline_keyboard:
            rows.append([
                Btn("★" if now_saved else "⭐", callback_data=b.callback_data)
                if b.callback_data == f"sv:{qid}" else b
                for b in row
            ])
        try:
            await query.edit_message_reply_markup(reply_markup=Markup(rows))
        except TelegramError:
            pass
    return "⭐ Saralanganlarga qo'shildi" if now_saved else "Saralanganlardan olib tashlandi"


async def route(ctx, query, data: str):
    chat_id = query.message.chat_id
    uid = query.from_user.id

    # vaqti tugagan imtihonda javob qabul qilinmaydi
    s0 = sess(ctx)
    if s0 and s0["mode"] == "exam" and data[:2] in ("a:", "ok") and exam_left(s0) <= 0:
        await strip_kb(query)
        await finish_exam(ctx, chat_id, uid, timeout=True)
        return "Vaqt tugadi."

    if data == "menu":
        ctx.user_data["s"] = None
        ctx.user_data["await_search"] = ctx.user_data["await_date"] = False
        await strip_kb(query)
        await send_menu(ctx.bot, chat_id)

    elif data.startswith("ex:"):
        await start_session(ctx, chat_id, "exam", quiz.make_exam(), cls=int(data[3:]), uid=uid)

    elif data == "pr":
        ids = ALL_IDS[:]
        random.shuffle(ids)
        await start_session(ctx, chat_id, "random", ids)

    elif data == "img":
        ids = quiz.IMAGE_IDS[:]
        random.shuffle(ids)
        await start_session(ctx, chat_id, "img", ids)

    elif data == "wr":
        ids = quiz.wrong_ids(uid)
        if not ids:
            return "Hozircha xatolaringiz yo'q 👍 Avval mashq qiling."
        random.shuffle(ids)
        await start_session(ctx, chat_id, "wrong", ids)

    elif data == "srs":
        ids = quiz.srs_due(uid)
        if not ids:
            due, total = quiz.srs_counts(uid)
            return ("Hozir takrorlash uchun savol yo'q 👍"
                    + (f" Kutilayotgan: {total} ta (muddati kelganda chiqadi)." if total else
                       " Xato qilingan savollar shu yerga tushadi."))
        await start_session(ctx, chat_id, "srs", ids)

    elif data == "stm":
        rows = [
            [Btn("🃏 Flashcard (faol eslash)", callback_data="fc")],
            [Btn("🎲 Aralash", callback_data="sm:rand"), Btn("❌ Xatolarim", callback_data="sm:wrong")],
            [Btn("🖼 Rasmli savollar", callback_data="sm:img")],
        ] + block_rows("sb") + [[Btn("🏠 Menyu", callback_data="menu")]]
        await ctx.bot.send_message(
            chat_id, "📖 <b>Yodlash rejimi</b> — javoblar darrov ko'rsatiladi.\nNimani yodlaymiz?",
            parse_mode=HTML, reply_markup=Markup(rows),
        )

    elif data.startswith("sm:"):
        kind = data[3:]
        if kind == "wrong":
            ids = quiz.wrong_ids(uid)
            if not ids:
                return "Hozircha xatolaringiz yo'q 👍"
        elif kind == "img":
            ids = quiz.IMAGE_IDS[:]
        else:
            ids = ALL_IDS[:]
        random.shuffle(ids)
        await start_session(ctx, chat_id, "study", ids)

    elif data.startswith("sb:"):
        st = int(data[3:])
        await start_session(ctx, chat_id, "study", list(range(st, min(st + quiz.BLOCK, TOTAL + 1))))

    elif data in ("sn", "sp"):
        s = sess(ctx)
        if not s or s["mode"] != "study":
            return "Yodlash rejimi yopilgan. /start ni bosing."
        step = 1 if data == "sn" else -1
        if not 0 <= s["i"] + step < len(s["queue"]):
            return "Bu oxirgi savol." if step == 1 else "Bu birinchi savol."
        await strip_kb(query)
        s["i"] += step
        await show_current(ctx, chat_id)

    elif data == "blk":
        rows = block_rows("b") + [[Btn("🏠 Menyu", callback_data="menu")]]
        await ctx.bot.send_message(chat_id, "📚 Bo'limni tanlang:", reply_markup=Markup(rows))

    elif data.startswith("b:"):
        st = int(data[2:])
        await start_session(ctx, chat_id, "blk", list(range(st, min(st + quiz.BLOCK, TOTAL + 1))))

    elif data == "num":
        await ctx.bot.send_message(chat_id, f"Savol raqamini yuboring (1–{TOTAL}):")

    elif data == "st":
        await send_stats(ctx.bot, chat_id, uid)

    # --- lug'at
    elif data == "lex":
        ctx.user_data["await_gl"] = True
        await ctx.bot.send_message(
            chat_id,
            "🔤 <b>Lug'at</b>\nKoreyscha yoki o'zbekcha so'z yuboring (masalan: <code>교차로</code> yoki "
            "<code>chorraha</code>), yoki to'liq ro'yxatni oching.",
            parse_mode=HTML,
            reply_markup=Markup([[Btn("📖 Ro'yxat", callback_data="gp:0")],
                                 [Btn("🏠 Menyu", callback_data="menu")]]),
        )

    elif data.startswith("gp:"):
        text, k = glossary.page(int(data[3:]))
        nav = []
        if k > 0:
            nav.append(Btn("⬅️", callback_data=f"gp:{k - 1}"))
        if k < glossary.PAGES - 1:
            nav.append(Btn("➡️", callback_data=f"gp:{k + 1}"))
        rows = ([nav] if nav else []) + [[Btn("🏠 Menyu", callback_data="menu")]]
        await safe_edit(query, text, Markup(rows))

    elif data.startswith("tm:"):
        _, qid, r = data.split(":")
        q = QUESTIONS[int(qid)]
        terms = glossary.terms_for(q, with_expl=(r == "1"))
        if not terms:
            return "Bu savolda lug'at so'zlari topilmadi."
        await ctx.bot.send_message(
            chat_id, glossary.format_terms(f"№ {q['id']} — so'zlar", terms), parse_mode=HTML
        )

    # --- sozlamalar
    elif data == "set":
        text, kb = settings_main(uid)
        await ctx.bot.send_message(chat_id, text, parse_mode=HTML, reply_markup=kb)

    elif data == "rem":
        text, kb = settings_view(uid)
        await safe_edit(query, text, kb)

    elif data == "fast:st":
        quiz.set_setting(uid, fast=not quiz.get_settings(uid)["fast"])
        text, kb = settings_main(uid)
        await safe_edit(query, text, kb)

    elif data == "fast:tg":
        new = not quiz.get_settings(uid)["fast"]
        quiz.set_setting(uid, fast=new)
        s = sess(ctx)
        if s:
            s["fast"] = new
            q = QUESTIONS[s["queue"][s["i"]]]
            try:
                await query.edit_message_reply_markup(reply_markup=question_kb(s, q, reveal=s["done"]))
            except TelegramError:
                pass
        return "⚡ Tez rejim yoqildi" if new else "Tez rejim o'chirildi"

    elif data.startswith("acc:"):
        if not access.is_owner(uid):
            return "Bu faqat bot egasi uchun."
        act = data[4:]
        if act == "tg":
            access.set_private(not access.private_mode())
            text, kb = settings_main(uid)
            await safe_edit(query, text, kb)
        elif act == "inv":
            await send_invite(ctx, chat_id, uid)
        elif act == "ls":
            await send_allowed_list(ctx, chat_id)

    # --- flashcard
    elif data == "fc":
        cs = quiz.card_stats(uid)
        rows = [[Btn("🃏 Hammasi: muddati kelgan + yangi", callback_data="fcs:all")],
                [Btn("⭐ Faqat saralanganlar", callback_data="fcs:saved")],
                [Btn("❌ Faqat xato savollar", callback_data="fcs:wrong")],
                [Btn("🏠 Menyu", callback_data="menu")]]
        await ctx.bot.send_message(
            chat_id,
            "🃏 <b>Flashcard — faol eslash</b>\n"
            "Savol ko'rsatiladi, siz javobni <b>o'zingiz eslaysiz</b>, so'ng «👁 Javobni ko'rish»ni bosib "
            "tekshirasiz. «✅ Bilaman» desangiz karta 1→3→7→14→30 kundan keyin qaytadi, «🔁 Yana "
            "takrorlash» desangiz tez orada qayta chiqadi.\n\n"
            f"Muddati kelgan: <b>{cs['due']}</b> · Yangi: <b>{cs['new']}</b> · "
            f"O'zlashtirilgan: <b>{cs['learned']}</b>",
            parse_mode=HTML, reply_markup=Markup(rows))

    elif data.startswith("fcs:"):
        src = data[4:]
        ids = quiz.saved_ids(uid) if src == "saved" else quiz.wrong_ids(uid) if src == "wrong" else None
        if ids is not None and not ids:
            return "Bu bo'limda savol yo'q."
        queue = quiz.card_queue(uid, ids)
        if not queue:
            return "Hozircha karta yo'q 👍 Muddati kelganda o'zi chiqadi."
        await start_session(ctx, chat_id, "card", queue, again=0, known=0)

    elif data == "fcv":
        s = sess(ctx)
        if not s or s["mode"] != "card" or s.get("revealed"):
            return "Bu karta allaqachon ochilgan."
        q = QUESTIONS[s["queue"][s["i"]]]
        s["revealed"] = True
        await safe_edit(query, quiz.format_question(q, reveal=True, header=header_for(s)), card_kb(s, q, True))

    elif data.startswith("fck:"):
        s = sess(ctx)
        if not s or s["mode"] != "card" or not s.get("revealed"):
            return "Avval «Javobni ko'rish»ni bosing."
        qid = s["queue"][s["i"]]
        known = data[4:] == "1"
        quiz.card_grade(uid, qid, known)
        s["revealed"] = False
        if known:
            s["known"] = s.get("known", 0) + 1
        else:
            s["again"] = s.get("again", 0) + 1
            if s["queue"].count(qid) < 3:            # shu sessiyada yana bir marta ko'rsatiladi
                s["queue"].append(qid)
        await strip_kb(query)
        await advance(ctx, chat_id)

    # --- zaxira va eksport
    elif data.startswith("bk:"):
        if not access.is_owner(uid):
            return "Bu faqat bot egasi uchun."
        act = data[3:]
        if act == "get":
            try:
                path = await asyncio.to_thread(backup.make_backup, "manual")
                await ctx.bot.send_document(
                    chat_id, document=path, filename=path.name,
                    caption="💾 Zaxira nusxa (statistika, saralanganlar, sozlamalar). Token bu faylda yo'q.")
            except Exception:
                log.exception("zaxira xatosi")
                return "Zaxira yaratib bo'lmadi."
        elif act == "help":
            await ctx.bot.send_message(
                chat_id,
                "♻️ <b>Tiklash</b>\nZaxira faylini (<code>.db</code>) shu chatga yuboring va fayl izohiga "
                "<code>/restore</code> deb yozing. Bot avval joriy bazaning nusxasini oladi, keyin tiklaydi.",
                parse_mode=HTML)
        elif act == "tg":
            quiz.set_bs("backup_tg", "0" if quiz.get_bs("backup_tg", "1") == "1" else "1")
            text, kb = settings_main(uid)
            await safe_edit(query, text, kb)

    elif data == "rn:tg":
        if not access.is_owner(uid):
            return "Bu faqat bot egasi uchun."
        on = quiz.get_bs("renew_remind", "0") == "1"
        quiz.set_bs("renew_remind", "0" if on else "1")
        if not on:
            quiz.set_bs("renew_last", time.time())
        text, kb = settings_main(uid)
        await safe_edit(query, text, kb)
        return "Eslatma o'chirildi" if on else f"Har {RENEW_DAYS} kunda eslataman"

    elif data == "xp":
        await ctx.bot.send_document(
            chat_id, document=io.BytesIO(backup.export_user(uid)), filename=f"natijalarim_{uid}.json",
            caption="📤 Sizning ma'lumotlaringiz (faqat o'zingizniki).")

    # --- yangi bo'limlar
    elif data == "menu2":
        rows = [[Btn("🖼 Rasmli savollar", callback_data="img")],
                [Btn("📚 Bo'limlar (50 tadan)", callback_data="blk")],
                [Btn("#️⃣ Raqam bo'yicha", callback_data="num")],
                [Btn("🏠 Menyu", callback_data="menu")]]
        await ctx.bot.send_message(chat_id, "📂 <b>Boshqa mashqlar</b>", parse_mode=HTML,
                                   reply_markup=Markup(rows))

    elif data.startswith("go:"):
        _, key, m = data.split(":")
        ids = ids_for(key, uid)
        if not ids:
            return "Bu bo'limda savol yo'q."
        if m == "t" or key == "saved":
            random.shuffle(ids)
        mode = "topic" if key.startswith("t_") else key
        await start_session(ctx, chat_id, "study" if m == "s" else mode, ids)

    elif data == "nm":
        await send_choose(ctx, chat_id, "🔢 Raqamli savollar", "num", len(topics.NUMERIC_IDS),
                          note="\n<i>Javobi raqamga bog'liq savollar: jarima, tezlik, muddat, yosh…</i>")

    elif data == "svm":
        n = len(quiz.saved_ids(uid))
        if not n:
            return "Hali saralangan savol yo'q. Savol ostidagi ⭐ tugmasini bosing."
        await send_choose(ctx, chat_id, "⭐ Saralanganlar", "saved", n,
                          extra_rows=[[Btn("🗑 Hammasini tozalash", callback_data="svc")]])

    elif data == "svc":
        await ctx.bot.send_message(
            chat_id, "Saralanganlar ro'yxati to'liq tozalansinmi?",
            reply_markup=Markup([[Btn("✅ Ha, tozalash", callback_data="svc2"),
                                  Btn("Bekor qilish", callback_data="menu")]]))

    elif data == "svc2":
        quiz.clear_saved(uid)
        await strip_kb(query)
        await ctx.bot.send_message(chat_id, "🗑 Saralanganlar tozalandi.")

    elif data.startswith("sv:"):
        return await toggle_saved_btn(query, uid, int(data[3:]))

    elif data == "qs":
        ctx.user_data["await_search"] = True
        await ctx.bot.send_message(
            chat_id,
            "🔍 <b>Savol qidirish</b>\nKoreyscha so'z yuboring (masalan: <code>어린이 보호구역</code>, "
            "<code>과태료</code>). O'zbekcha so'z ham bo'ladi (masalan: <code>chorraha</code>) — u "
            "lug'at orqali koreyschaga o'giriladi.",
            parse_mode=HTML, reply_markup=Markup([[Btn("🏠 Menyu", callback_data="menu")]]))

    elif data == "qsx":
        text = ctx.user_data.get("last_text", "")
        if not text:
            return "Qidiruv so'zi topilmadi."
        await do_search(ctx, chat_id, text)

    elif data.startswith("qp:"):
        sr = ctx.user_data.get("sr")
        if not sr:
            return "Qidiruv natijalari eskirgan. Qaytadan qidiring."
        head, kb = search_view(sr, int(data[3:]))
        await safe_edit(query, head, kb)

    elif data.startswith("qv:"):
        sr = ctx.user_data.get("sr")
        await show_question_detail(ctx, chat_id, int(data[3:]), sr["page"] if sr else None)

    elif data == "tp":
        await send_topics(ctx, chat_id, uid)

    elif data == "tpw":
        key = topics.weakest(uid)
        ids = topics.ids_of(key)
        await send_choose(ctx, chat_id, topics.label(key), f"t_{key}", len(ids))

    elif data.startswith("tp:"):
        key = data[3:]
        if key not in topics.BY_KEY:
            return "Mavzu topilmadi."
        ids = topics.ids_of(key)
        await send_choose(ctx, chat_id, topics.label(key), f"t_{key}", len(ids))

    elif data == "pl":
        text, kb = plan_view(uid)
        await ctx.bot.send_message(chat_id, text, parse_mode=HTML, reply_markup=kb)

    elif data == "pc":
        ctx.user_data["await_date"] = True
        await ctx.bot.send_message(
            chat_id,
            "📅 Imtihon sanasini yozing, masalan: <code>15.12.2026</code>\nYoki tez tanlang:",
            parse_mode=HTML,
            reply_markup=Markup([[Btn("1 hafta", callback_data="pd:7"), Btn("2 hafta", callback_data="pd:14"),
                                  Btn("1 oy", callback_data="pd:30"), Btn("2 oy", callback_data="pd:60")],
                                 [Btn("🏠 Menyu", callback_data="menu")]]))

    elif data.startswith("pd:"):
        st = quiz.get_settings(uid)
        quiz.set_setting(uid, exam_date=plan.quick_date(int(data[3:]), st["tz"]).isoformat())
        ctx.user_data["await_date"] = False
        text, kb = plan_view(uid)
        await safe_edit(query, text, kb)

    elif data == "px":
        quiz.set_setting(uid, exam_date=None)
        text, kb = plan_view(uid)
        await safe_edit(query, text, kb)

    elif data.startswith("pg:"):
        quiz.set_setting(uid, goal=int(data[3:]))
        text, kb = plan_view(uid)
        await safe_edit(query, text, kb)

    elif data == "lbp":
        await send_lb_private(ctx, chat_id, uid)

    elif data.startswith("lb:"):
        chat = query.message.chat
        if chat.type == "private":
            return "Bu tugma faqat guruhda ishlaydi. Guruhda /reyting yuboring."
        act = data[3:]
        if act == "j":
            quiz.lb_join(chat_id, uid, query.from_user.first_name or "Ishtirokchi", chat.title or "")
        elif act == "l":
            quiz.lb_leave(chat_id, uid)
        await safe_edit(query, leaderboard.render(chat_id, chat.title or ""), lb_kb())

    elif data.startswith(("rm:", "goal:", "tz:")):
        key, val = data.split(":")
        if key == "rm":
            quiz.set_setting(uid, remind=None if val == "off" else int(val))
        elif key == "goal":
            quiz.set_setting(uid, goal=int(val))
        else:
            quiz.set_setting(uid, tz=int(val))
        text, kb = settings_view(uid)
        await safe_edit(query, text, kb)

    # --- javob berish
    elif data.startswith("a:"):
        _, qid, i = data.split(":")
        return await handle_option(ctx, query, int(qid), int(i))

    elif data.startswith("ok:"):
        s = sess(ctx)
        qid = int(data[3:])
        if not s or s["done"] or s["queue"][s["i"]] != qid:
            return "Bu savol allaqachon yopilgan."
        q = QUESTIONS[qid]
        if len(s["chosen"]) != len(q["a"]):
            return f"Avval {len(q['a'])} ta javob tanlang."
        await finalize(ctx, query, s, q)

    elif data == "nx":
        s = sess(ctx)
        if not s:
            await send_menu(ctx.bot, chat_id)
        else:
            await strip_kb(query)
            await advance(ctx, chat_id)

    elif data == "fin":
        s = sess(ctx)
        if s and s["mode"] == "exam":
            await strip_kb(query)
            await finish_exam(ctx, chat_id, uid)
        else:
            return "Faol imtihon yo'q."

    elif data.startswith("tr:"):
        _, qid, r = data.split(":")
        q = QUESTIONS[int(qid)]
        try:
            await query.answer("Tarjima qilinmoqda…")
        except TelegramError:
            pass
        tr = await translate.get_translation(q)
        if not tr:
            return "Tarjima hozir ishlamadi. Birozdan so'ng qayta urinib ko'ring."
        await ctx.bot.send_message(
            chat_id, quiz.format_translation(q, tr, reveal=(r == "1")), parse_mode=HTML
        )

    elif data.startswith("rv:"):
        await strip_kb(query)
        await show_review(ctx, chat_id, int(data[3:]))
    return None


async def on_callback(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    if not await gate(update, ctx):
        return
    note = None
    try:
        note = await route(ctx, query, query.data or "")
    except Exception:
        log.exception("callback xatosi: %s", query.data)
        note = "Xatolik yuz berdi. /start ni bosing."
    try:
        await query.answer(note) if note else await query.answer()
    except TelegramError:
        pass


# ------------------------------------------------------------ kirish nazorati
async def gate(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> bool:
    """Foydalanuvchiga ruxsat bormi? Egasi yo'q bo'lsa — birinchi /start egasi bo'ladi."""
    user = update.effective_user
    chat = update.effective_chat
    if user is None:
        return False
    uid = user.id
    ctx.user_data["uid"] = uid
    private = chat is None or chat.type == "private"
    query = update.callback_query
    msg = update.message

    if not access.owner_ids():
        if msg and private and (msg.text or "").startswith("/start"):
            access.claim(uid)
            await ctx.bot.send_message(
                chat.id,
                "🔑 <b>Siz botning egasi sifatida belgilandingiz.</b>\n"
                "Bot hozir <b>yopiq rejimda</b>: faqat siz va siz taklif qilganlar foydalana oladi.\n"
                "• Do'stni qo'shish: /taklif\n• Rejimni o'zgartirish: ⚙️ Sozlamalar\n"
                f"• Sizning ID: <code>{uid}</code>",
                parse_mode=HTML,
            )
            return True
        if query:
            await query.answer("Bot hali sozlanmagan. Egasi /start bosishi kerak.", show_alert=True)
        elif msg and private:
            await msg.reply_text("Bot hali sozlanmagan. Egasi /start bosishi kerak.")
        return False

    if access.is_allowed(uid):
        return True
    if query:
        await query.answer("🔒 Bot yopiq rejimda. Bot egasidan taklif havolasini so'rang.", show_alert=True)
    elif msg and private:
        await msg.reply_text(
            f"🔒 Bu bot yopiq rejimda. Foydalanish uchun bot egasidan taklif havolasini so'rang.\n"
            f"Sizning ID: {uid}"
        )
    return False


async def send_invite(ctx, chat_id: int, uid: int) -> None:
    code = quiz.create_invite(uid)
    link = f"https://t.me/{ctx.bot.username}?start=inv_{code}"
    await ctx.bot.send_message(
        chat_id,
        "👥 <b>Taklif havolasi</b> (bir marta ishlatiladi, 7 kun amal qiladi):\n"
        f"{link}\n\nUni do'stingizga yuboring — havolani ochib «Start» bossa, botga kirish ochiladi.",
        parse_mode=HTML,
    )


async def send_allowed_list(ctx, chat_id: int) -> None:
    rows = quiz.list_allowed()
    lines = ["📋 <b>Ruxsat berilganlar</b>", ""]
    lines += [f"• {esc(name or '—')} — <code>{uid}</code>" for uid, name in rows] or ["Hozircha hech kim yo'q."]
    lines += ["", "Olib tashlash: <code>/chiqar ID</code>"]
    await ctx.bot.send_message(chat_id, "\n".join(lines), parse_mode=HTML)


# ------------------------------------------------------------ buyruqlar / matn
async def cmd_start(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    chat = update.effective_chat
    user = update.effective_user
    if chat.type != "private":
        return
    args = ctx.args or []
    if user and args and args[0].startswith("inv_") and access.owner_ids():
        ok = quiz.redeem_invite(args[0][4:], user.id, user.first_name or "")
        await ctx.bot.send_message(
            chat.id, "✅ Taklif qabul qilindi — botdan foydalanishingiz mumkin." if ok
            else "⚠️ Taklif havolasi yaroqsiz yoki eskirgan.")
    if not await gate(update, ctx):
        return
    ctx.user_data["s"] = None
    ctx.user_data["await_search"] = ctx.user_data["await_date"] = False
    await send_menu(ctx.bot, chat.id)


async def cmd_stats(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    if not await gate(update, ctx):
        return
    await send_stats(ctx.bot, update.effective_chat.id, update.effective_user.id)


async def cmd_rating(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    chat = update.effective_chat
    if not await gate(update, ctx):
        return
    if chat.type == "private":
        await send_lb_private(ctx, chat.id, update.effective_user.id)
        return
    quiz.lb_title(chat.id, chat.title or "")
    await ctx.bot.send_message(chat.id, leaderboard.render(chat.id, chat.title or ""),
                               parse_mode=HTML, reply_markup=lb_kb())


async def _owner_only(update: Update, ctx) -> bool:
    if update.effective_chat.type != "private":
        return False
    if not await gate(update, ctx):
        return False
    if not access.is_owner(update.effective_user.id):
        await update.message.reply_text("Bu buyruq faqat bot egasi uchun.")
        return False
    return True


async def cmd_invite(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    if await _owner_only(update, ctx):
        await send_invite(ctx, update.effective_chat.id, update.effective_user.id)


async def cmd_users(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    if await _owner_only(update, ctx):
        await send_allowed_list(ctx, update.effective_chat.id)


async def cmd_remove(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    if not await _owner_only(update, ctx):
        return
    arg = (ctx.args or [""])[0]
    if not arg.isdigit():
        await update.message.reply_text("Ishlatilishi: /chiqar 123456789")
        return
    ok = quiz.remove_allowed(int(arg))
    await update.message.reply_text("✅ Olib tashlandi." if ok else "Bunday foydalanuvchi ro'yxatda yo'q.")


async def cmd_closed(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    if await _owner_only(update, ctx):
        access.set_private(True)
        await update.message.reply_text("🔒 Yopiq rejim yoqildi: faqat siz va taklif qilinganlar.")


async def cmd_open(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    if await _owner_only(update, ctx):
        access.set_private(False)
        await update.message.reply_text("🔓 Ochiq rejim: botni topgan har kim foydalanishi mumkin.")


async def cmd_id(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text(f"Sizning Telegram ID: {update.effective_user.id}")


async def on_text(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    if not await gate(update, ctx):
        return
    text = (update.message.text or "").strip()
    chat_id = update.effective_chat.id
    uid = update.effective_user.id

    if ctx.user_data.get("await_date"):
        st = quiz.get_settings(uid)
        today = plan.today_of(st["tz"])
        d = plan.parse_date(text, today)
        if d is None or d < today:
            await update.message.reply_text("Sanani shunday yozing: 15.12.2026 (bugundan keyingi sana bo'lsin).")
            return
        quiz.set_setting(uid, exam_date=d.isoformat())
        ctx.user_data["await_date"] = False
        ptext, kb = plan_view(uid)
        await ctx.bot.send_message(chat_id, ptext, parse_mode=HTML, reply_markup=kb)
        return

    if ctx.user_data.get("await_search"):
        if text.isdigit() and 1 <= int(text) <= TOTAL:
            await show_question_detail(ctx, chat_id, int(text))
        else:
            await do_search(ctx, chat_id, text)
        return

    if text.isdigit():
        n = int(text)
        if 1 <= n <= TOTAL:
            cur = ctx.user_data.get("s")
            mode = "study" if (cur and cur.get("mode") == "study") else "seq"
            await start_session(ctx, chat_id, mode, list(range(n, TOTAL + 1)))
        else:
            await update.message.reply_text(f"1 dan {TOTAL} gacha raqam yuboring.")
        return

    ctx.user_data["last_text"] = text
    found = glossary.search(text)
    if found:
        ctx.user_data["await_gl"] = False
        await ctx.bot.send_message(
            chat_id, glossary.format_terms(f"Lug'at: {text}", found[:20]), parse_mode=HTML,
            reply_markup=Markup([[Btn("🔍 Shu so'z bo'yicha savollar", callback_data="qsx")],
                                 [Btn("🏠 Menyu", callback_data="menu")]]),
        )
    elif any("가" <= ch <= "힣" for ch in text) and len(text) >= 2:
        await do_search(ctx, chat_id, text)
    elif ctx.user_data.get("await_gl"):
        await update.message.reply_text("Bunday so'z lug'atda topilmadi. Boshqa so'z yuboring.")
    else:
        await send_menu(ctx.bot, chat_id)


async def on_document(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    """Egasi zaxira faylini «/restore» izohi bilan yuborsa, bazani tiklaydi."""
    if not await gate(update, ctx):
        return
    msg = update.message
    if not (msg.caption or "").strip().lower().startswith("/restore"):
        return
    if not access.is_owner(update.effective_user.id):
        await msg.reply_text("Tiklash faqat bot egasi uchun.")
        return
    doc = msg.document
    if doc.file_size and doc.file_size > 20 * 1024 * 1024:
        await msg.reply_text("Fayl juda katta (20 MB dan oshmasin).")
        return
    backup.BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    tmp = backup.BACKUP_DIR / f"yuklangan_{int(time.time())}.db"
    try:
        f = await doc.get_file()
        await f.download_to_drive(tmp)
        ok, why = backup.validate(tmp)
        if not ok:
            await msg.reply_text("❌ " + why)
            return
        pre = await asyncio.to_thread(backup.restore, tmp)
        await msg.reply_text(f"✅ Baza tiklandi. Oldingi holat nusxasi: {pre.name}")
    except Exception:
        log.exception("tiklash xatosi")
        await msg.reply_text("❌ Tiklab bo'lmadi. Fayl to'g'ri ekanini tekshiring.")
    finally:
        tmp.unlink(missing_ok=True)


async def on_error(update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    log.error("Kutilmagan xato", exc_info=ctx.error)


async def post_init(app: Application) -> None:
    await app.bot.set_my_commands([
        ("start", "Bosh menyu"),
        ("menu", "Bosh menyu"),
        ("stats", "Statistika"),
        ("reyting", "Haftalik reyting (guruhda)"),
        ("taklif", "Do'stni taklif qilish (egasi)"),
        ("id", "Telegram ID'ni ko'rish"),
    ])
    task = asyncio.create_task(reminder_loop(app))      # kundalik eslatmalar
    _TASKS.add(task)
    task.add_done_callback(_TASKS.discard)


def main() -> None:
    token = os.environ.get("BOT_TOKEN") or os.environ.get("TELEGRAM_BOT_TOKEN")
    if not token:
        raise SystemExit("BOT_TOKEN (yoki TELEGRAM_BOT_TOKEN) o'rnatilmagan.")
    quiz.init_db()
    persistence = PicklePersistence(
        filepath=str(quiz.DATA_DIR / "state.pkl"),
        store_data=PersistenceInput(bot_data=False, chat_data=False, callback_data=False),
    )
    app = Application.builder().token(token).persistence(persistence).post_init(post_init).build()
    app.add_handler(CommandHandler(["start", "menu"], cmd_start))
    app.add_handler(CommandHandler("stats", cmd_stats))
    app.add_handler(CommandHandler(["reyting", "rating"], cmd_rating))
    app.add_handler(CommandHandler("taklif", cmd_invite))
    app.add_handler(CommandHandler("foydalanuvchilar", cmd_users))
    app.add_handler(CommandHandler("chiqar", cmd_remove))
    app.add_handler(CommandHandler("yopiq", cmd_closed))
    app.add_handler(CommandHandler("ochiq", cmd_open))
    app.add_handler(CommandHandler("id", cmd_id))
    app.add_handler(CallbackQueryHandler(on_callback))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND & filters.ChatType.PRIVATE, on_text))
    app.add_handler(MessageHandler(filters.Document.ALL & filters.ChatType.PRIVATE, on_document))
    app.add_error_handler(on_error)
    log.info("Bot ishga tushdi (%d ta savol, %d ta rasmli)", TOTAL, len(quiz.IMAGE_IDS))
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
