# -*- coding: utf-8 -*-
"""Guruh uchun haftalik reyting (dushanba–yakshanba, Koreya vaqti)."""
import time
from datetime import datetime, timedelta

import quiz
from quiz import esc

MEDALS = ["🥇", "🥈", "🥉"]


def week_range(now: float = None, tz: int = 9):
    d = datetime.utcfromtimestamp((now or time.time()) + tz * 3600).date()
    mon = d - timedelta(days=d.weekday())
    return mon.isoformat(), (mon + timedelta(days=6)).isoformat()


def ranking(chat_id: int, now: float = None) -> list:
    members = quiz.lb_members(chat_id)
    start, end = week_range(now)
    sc = quiz.weekly_scores([m[0] for m in members], start, end)
    rows = []
    for uid, name in members:
        n, ok = sc.get(uid, (0, 0))
        rows.append((ok, (ok / n) if n else 0.0, n, name, uid))
    rows.sort(key=lambda r: (-r[0], -r[1], r[3].lower()))
    return rows


def render(chat_id: int, title: str = "", now: float = None) -> str:
    start, end = week_range(now)
    rows = ranking(chat_id, now)
    lines = [f"🏆 <b>Haftalik reyting</b>" + (f" — {esc(title)}" if title else ""),
             f"<i>{start[8:]}.{start[5:7]} – {end[8:]}.{end[5:7]} (Koreya vaqti, dushanba–yakshanba)</i>", ""]
    if not rows:
        lines.append("Hozircha ishtirokchi yo'q. «➕ Qo'shilish» tugmasini bosing.")
    for i, (ok, acc, n, name, _) in enumerate(rows[:15]):
        medal = MEDALS[i] if i < 3 else f"{i + 1}."
        lines.append(f"{medal} <b>{esc(name)}</b> — {ok} ta to'g'ri ({acc * 100:.0f}% · {n} ta urinish)")
    lines += ["", "<i>Ball = shu hafta berilgan to'g'ri javoblar soni.</i>"]
    return "\n".join(lines)
