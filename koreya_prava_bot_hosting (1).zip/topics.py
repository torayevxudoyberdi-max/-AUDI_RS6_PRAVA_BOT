# -*- coding: utf-8 -*-
"""Mavzular (kalit so'zlar bo'yicha AVTOMATIK guruhlash) va raqamli savollar.

Rasmiy PDF savollar bankida mavzu sarlavhalari yo'q, shuning uchun mavzular kalit so'zlar
bilan aniqlanadi. Aniq moslik topilmasa, savol "Boshqa" mavzusiga tushadi (noto'g'ri
mavzuga majburan qo'shilmaydi)."""
import re

import quiz
from quiz import QUESTIONS

# (kalit, emoji, nomi, kalit so'zlar)
TOPICS = [
    ("fine", "💰", "Jarima va ballar",
     ["벌점", "범칙금", "과태료", "벌금", "처벌", "징역", "과징금", "감경", "가중"]),
    ("signs", "🚦", "Svetofor va belgilar",
     ["신호등", "신호기", "신호", "안전표지", "표지", "노면표시", "황색", "적색", "녹색", "점멸", "화살표",
      "실선", "점선", "규제표지", "주의표지", "지시표지"]),
    ("inter", "🚘", "Chorraha va burilish",
     ["교차로", "좌회전", "우회전", "회전교차로", "유턴", "비보호", "로터리", "직진"]),
    ("speed", "🏎", "Tezlik va masofa",
     ["속도", "안전거리", "제동거리", "정지거리", "공주거리", "서행", "과속", "급제동", "시속"]),
    ("park", "🅿️", "To'xtash va parkovka", ["주차", "정차", "갓길", "견인"]),
    ("ped", "👣", "Piyodalar va himoya zonasi",
     ["보행자", "횡단보도", "보호구역", "어린이", "영유아", "보도", "통학버스", "장애인", "노인"]),
    ("license", "🪪", "Guvohnoma va qonun",
     ["운전면허", "면허", "적성검사", "갱신", "연습", "면허증", "국제운전", "임시운전", "교통안전교육"]),
    ("tech", "🔧", "Texnik holat va ekologiya",
     ["엔진", "타이어", "브레이크", "배터리", "정비", "점검", "연료", "배출가스", "친환경", "전기자동차",
      "수소", "냉각수", "계기판", "변속기", "클러치", "조향", "현가", "에어백", "정기검사", "소음"]),
    ("accident", "🚑", "Hodisa va birinchi yordam",
     ["교통사고", "응급", "심폐소생", "지혈", "구호", "보험", "뺑소니", "인공호흡", "부상", "사상자",
      "소화기", "화재", "사고"]),
    ("hazard", "🌧", "Xavfli sharoitlar",
     ["야간", "안개", "빗길", "눈길", "결빙", "빙판", "음주", "졸음", "난폭", "보복운전", "피로",
      "강풍", "폭우", "수막현상", "페이드", "베이퍼록", "스탠딩웨이브", "장마"]),
    ("special", "🏍", "Maxsus transport",
     ["이륜자동차", "이륜차", "자전거", "개인형 이동장치", "전동킥보드", "긴급자동차", "건설기계",
      "화물", "원동기장치", "트레일러", "승합자동차", "오토바이"]),
    ("lane", "🛣", "Quvib o'tish va qatorlar",
     ["앞지르기", "진로변경", "끼어들기", "고속도로", "중앙선", "합류", "일방통행",
      "자동차전용도로"]),
]
SITU = ("situ", "📷", "Vaziyatli savollar (rasmli)", [])
OTHER = ("other", "❓", "Boshqa (aniq mavzusiz)", [])
ALL_TOPICS = TOPICS + [SITU, OTHER]
_SITU_RE = re.compile(r"다음 상황|다음과 같은 상황|다음의 도로|다음 도로|도로 상황|상황에서")
BY_KEY = {t[0]: t for t in ALL_TOPICS}
MIN_SCORE = 3.0            # kamida savol matnida 1 ta kalit so'z yoki unga teng dalil


def _count(text: str, kws: list) -> int:
    return sum(text.count(k) for k in kws)


def classify(q: dict) -> str:
    if q["img"] and _SITU_RE.search(q["q"]):
        return "situ"          # rasmli vaziyat savollari — kalit so'z bilan ishonchli ajratib bo'lmaydi
    stem = q["q"]
    ctx = " ".join(q["ctx"])
    opts = " ".join(q["o"])
    expl = q["e"]
    best, best_score = "other", 0.0
    for key, _, _, kws in TOPICS:       # tenglikda ro'yxatdagi tartib ustun
        score = 3 * _count(stem, kws) + 2 * _count(ctx, kws) + _count(opts, kws) + 0.5 * _count(expl, kws)
        if score > best_score:
            best, best_score = key, score
    return best if best_score >= MIN_SCORE else "other"


TOPIC_OF = {qid: classify(q) for qid, q in QUESTIONS.items()}
_IDS = {k: [] for k in BY_KEY}
for _qid in sorted(TOPIC_OF):
    _IDS[TOPIC_OF[_qid]].append(_qid)


def ids_of(key: str) -> list:
    return list(_IDS.get(key, []))


def label(key: str) -> str:
    t = BY_KEY[key]
    return f"{t[1]} {t[2]}"


# ---- Raqamli savollar: javob raqamga (jarima, tezlik, muddat, yosh ...) bog'liq
def _is_numeric(q: dict) -> bool:
    n_opts = sum(1 for o in q["o"] if quiz._RE_NUM.search(o))
    asks_number = re.search(r"몇|얼마|며칠", q["q"]) is not None
    has_digit = any(re.search(r"\d", o) for o in q["o"])
    return n_opts >= 2 or (asks_number and has_digit)


NUMERIC_IDS = [qid for qid in sorted(QUESTIONS) if _is_numeric(QUESTIONS[qid])]


# ---- Foydalanuvchi bo'yicha mavzu statistikasi
def stats(uid: int) -> list:
    """[(key, jami, yechilgan, to'g'ri_urinish, noto'g'ri_urinish, aniqlik|None)]"""
    am = quiz.answers_map(uid)
    out = []
    for key, _, _, _ in ALL_TOPICS:
        ids = _IDS[key]
        solved = [i for i in ids if i in am]
        ok = sum(am[i][0] for i in solved)
        bad = sum(am[i][1] for i in solved)
        acc = ok * 100 / (ok + bad) if (ok + bad) else None
        out.append((key, len(ids), len(solved), ok, bad, acc))
    return out


def weakest(uid: int, min_attempts: int = 5):
    """Aniqlik eng past mavzu (kamida min_attempts urinish); bo'lmasa — eng kam yechilgani."""
    st = [r for r in stats(uid) if r[0] != "other" and r[1] > 0]
    rated = [r for r in st if (r[3] + r[4]) >= min_attempts]
    if rated:
        return min(rated, key=lambda r: r[5])[0]
    return min(st, key=lambda r: r[2] / r[1])[0]
