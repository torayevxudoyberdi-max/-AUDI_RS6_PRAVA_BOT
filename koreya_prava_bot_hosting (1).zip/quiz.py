# -*- coding: utf-8 -*-
"""Savollar bazasi, matn formatlash va SQLite statistikasi (Telegramga bog'liq emas)."""
import html
import json
import os
import random
import re
import sqlite3
import time
from contextlib import contextmanager
from pathlib import Path

BASE = Path(__file__).resolve().parent
IMG_DIR = BASE / "images"
# Xostingda (masalan FadeHost) doimiy papka — /data; boshqa joyda bot papkasining o'zi
_d = Path(os.environ.get("DATA_DIR", "/data"))
DATA_DIR = _d if (_d.is_dir() and os.access(_d, os.W_OK)) else BASE
DB_PATH = DATA_DIR / "data.db"

with open(BASE / "questions.json", encoding="utf-8") as f:
    QUESTIONS = {q["id"]: q for q in json.load(f)}

ALL_IDS = sorted(QUESTIONS)
TOTAL = len(ALL_IDS)
IMAGE_IDS = [i for i in ALL_IDS if QUESTIONS[i]["img"]]

CIRCLED = "①②③④⑤"
EXAM_SIZE = 40                 # haqiqiy imtihonda 40 ta savol
PASS_SCORE = {1: 70, 2: 60}    # 1-tur (제1종) 70 ball, 2-tur (제2종) 60 ball
POINTS_PER_Q = 100 / EXAM_SIZE
BLOCK = 50
EXAM_SECONDS = 40 * 60        # haqiqiy imtihon vaqti
SRS_DAYS = {1: 1, 2: 3, 3: 7}  # takrorlash oraliqlari (kun)
DEFAULT_GOAL = 20
DEFAULT_TZ = 9                 # Koreya vaqti (UTC+9)
MAX_LEN = 4000                 # Telegram limiti 4096


def esc(s: str) -> str:
    return html.escape(s, quote=False)


# Kalit joylarni qalin qilib ko'rsatish: raqamlar+birliklar (tezlik, jarima, yosh, muddat ...)
# va "tuzoq" so'zlar (옳지 않은, 모두, 반드시 ...)
_NUM = (r"(?:시속\s*)?\d+(?:[.,]\d+)?\s*"
        r"(?:킬로미터|미터|센티미터|킬로그램|톤|km/h|km|cm|kg|m(?![A-Za-z])|만\s*원|원|점|일|개월|년|세|시간|분|초|%|퍼센트|명|인|배|회|대)"
        r"(?:\s*(?:이상|이하|미만|이내|초과|까지|마다))?")
_FRAC = r"\d+분의\s*\d+|\d+/\d+"
_KEY = (r"[가-힣]{1,6}지\s*않(?:은|는)(?:\s*것)?|잘못된|틀린|아닌\s*것|"
        r"반드시|즉시|항상|모두|절대")
_RE_ALL = re.compile("|".join([_FRAC, _NUM, _KEY]))
_RE_NUM = re.compile("|".join([_FRAC, _NUM]))


def hl(text: str, keys: bool = True) -> str:
    """HTML-escape + kalit joylarni <b> bilan ajratish."""
    return (_RE_ALL if keys else _RE_NUM).sub(lambda m: f"<b>{m.group(0)}</b>", esc(text))


def is_correct(q: dict, chosen) -> bool:
    return sorted(chosen) == sorted(q["a"])


def make_exam() -> list:
    return random.sample(ALL_IDS, EXAM_SIZE)


def letters(nums) -> str:
    return " ".join(CIRCLED[i - 1] for i in sorted(nums)) or "—"


def format_question(q: dict, chosen=(), reveal=False, result=None, header="", card=False) -> str:
    need = len(q["a"])
    parts = [f"<b>{esc(header)}№ {q['id']}</b>", "", hl(q["q"])]
    if q["ctx"]:
        parts += ["", "\n".join("📍 " + esc(c) for c in q["ctx"])]
    parts.append("")
    for i, opt in enumerate(q["o"], start=1):
        body = hl(opt)
        if reveal:
            if i in q["a"]:
                parts.append(f"✅ {CIRCLED[i - 1]} <u>{body}</u>")      # to'g'ri javob — tagiga chiziq
            else:
                parts.append(f"{'❌' if i in chosen else '▫️'} {CIRCLED[i - 1]} {body}")
        else:
            parts.append(f"{'🔹' if i in chosen else '▫️'} {CIRCLED[i - 1]} {body}")
    parts.append("")
    if not reveal and card:
        parts.append("🃏 Avval javobni eslang, so'ng «👁 Javobni ko'rish»ni bosing.")
        return "\n".join(parts)
    if not reveal:
        if need == 1:
            parts.append("☝️ Bitta to'g'ri javobni tanlang.")
        else:
            parts.append(f"☝️ {need} ta to'g'ri javobni tanlang, so'ng «Tasdiqlash»ni bosing.")
        return "\n".join(parts)

    right = letters(q["a"])
    if result is True:
        parts.append(f"✅ <b>To'g'ri!</b> Javob: <u>{right}</u>")
    elif result is False:
        parts.append(f"❌ <b>Noto'g'ri.</b> To'g'ri javob: <u>{right}</u>")
    else:
        parts.append(f"👉 To'g'ri javob: <u>{right}</u>")
    text = "\n".join(parts)
    if q["e"]:
        room = MAX_LEN - len(text) - 250          # <b> teglari uchun zaxira
        if room > 50:
            expl = q["e"][:room] + ("…" if len(q["e"]) > room else "")
            text += "\n\n💡 <b>Izoh (한국어):</b> " + hl(expl, keys=False)
    return text


# ---------------------------------------------------------------- SQLite
@contextmanager
def _db():
    conn = sqlite3.connect(DB_PATH)
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db() -> None:
    with _db() as c:
        c.executescript(
            """
            CREATE TABLE IF NOT EXISTS answers(
                user_id INTEGER, qid INTEGER,
                n_ok INTEGER DEFAULT 0, n_bad INTEGER DEFAULT 0,
                last_ok INTEGER, ts REAL,
                PRIMARY KEY(user_id, qid));
            CREATE TABLE IF NOT EXISTS exams(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER, cls INTEGER, correct INTEGER,
                total INTEGER, seconds INTEGER, ts REAL);
            CREATE TABLE IF NOT EXISTS tr(qid INTEGER PRIMARY KEY, data TEXT);
            CREATE TABLE IF NOT EXISTS srs(
                user_id INTEGER, qid INTEGER, box INTEGER, due REAL,
                PRIMARY KEY(user_id, qid));
            CREATE TABLE IF NOT EXISTS settings(
                user_id INTEGER PRIMARY KEY, remind INTEGER,
                goal INTEGER DEFAULT 20, tz INTEGER DEFAULT 9, last_sent TEXT);
            CREATE TABLE IF NOT EXISTS daily(
                user_id INTEGER, day TEXT, n INTEGER DEFAULT 0, met INTEGER DEFAULT 0,
                PRIMARY KEY(user_id, day));
            CREATE TABLE IF NOT EXISTS saved(
                user_id INTEGER, qid INTEGER, ts REAL, PRIMARY KEY(user_id, qid));
            CREATE TABLE IF NOT EXISTS bot_settings(key TEXT PRIMARY KEY, value TEXT);
            CREATE TABLE IF NOT EXISTS allowed(
                user_id INTEGER PRIMARY KEY, name TEXT, added_by INTEGER, ts REAL);
            CREATE TABLE IF NOT EXISTS invites(
                code TEXT PRIMARY KEY, created_by INTEGER, ts REAL, used_by INTEGER);
            CREATE TABLE IF NOT EXISTS lb_members(
                chat_id INTEGER, user_id INTEGER, name TEXT, PRIMARY KEY(chat_id, user_id));
            CREATE TABLE IF NOT EXISTS lb_groups(chat_id INTEGER PRIMARY KEY, title TEXT);
            CREATE TABLE IF NOT EXISTS cards(
                user_id INTEGER, qid INTEGER, box INTEGER DEFAULT 0, due REAL, reps INTEGER DEFAULT 0,
                PRIMARY KEY(user_id, qid));
            """
        )
        _migrate(c)


def _migrate(c) -> None:
    # eski bazalarga yangi ustunlarni qo'shadi (ma'lumotlar saqlanib qoladi)
    def cols(t):
        return {r[1] for r in c.execute(f"PRAGMA table_info({t})")}
    if "fast" not in cols("settings"):
        c.execute("ALTER TABLE settings ADD COLUMN fast INTEGER DEFAULT 0")
    if "exam_date" not in cols("settings"):
        c.execute("ALTER TABLE settings ADD COLUMN exam_date TEXT")
    if "ok" not in cols("daily"):
        c.execute("ALTER TABLE daily ADD COLUMN ok INTEGER DEFAULT 0")


def _dayfmt(local_ts: float) -> str:
    return time.strftime("%Y-%m-%d", time.gmtime(local_ts))


def _settings(c, uid: int) -> dict:
    c.execute("INSERT OR IGNORE INTO settings(user_id, goal, tz) VALUES(?,?,?)",
              (uid, DEFAULT_GOAL, DEFAULT_TZ))
    r = c.execute("SELECT remind, goal, tz, last_sent, fast, exam_date FROM settings WHERE user_id=?",
                  (uid,)).fetchone()
    return dict(remind=r[0], goal=r[1], tz=r[2], last_sent=r[3], fast=bool(r[4]), exam_date=r[5])


def _streak(c, uid: int, tz: int, now: float) -> int:
    days = {r[0] for r in c.execute("SELECT day FROM daily WHERE user_id=? AND met=1", (uid,))}
    cur = now + tz * 3600
    if _dayfmt(cur) not in days:          # bugun hali bajarilmagan bo'lsa, kechadan hisoblaymiz
        cur -= 86400
    n = 0
    while _dayfmt(cur) in days:
        n += 1
        cur -= 86400
    return n


def get_settings(uid: int) -> dict:
    with _db() as c:
        return _settings(c, uid)


def set_setting(uid: int, **kw) -> None:
    with _db() as c:
        _settings(c, uid)
        for k, v in kw.items():
            if k not in ("remind", "goal", "tz", "fast", "exam_date"):
                raise ValueError(k)
            c.execute(f"UPDATE settings SET {k}=? WHERE user_id=?", (v, uid))


def record_answer(uid: int, qid: int, ok: bool, now: float = None) -> dict:
    """Javobni yozadi, takrorlash (SRS) va kunlik hisobni yangilaydi."""
    now = now or time.time()
    with _db() as c:
        c.execute(
            """INSERT INTO answers(user_id, qid, n_ok, n_bad, last_ok, ts)
               VALUES(?,?,?,?,?,?)
               ON CONFLICT(user_id, qid) DO UPDATE SET
                 n_ok = n_ok + excluded.n_ok, n_bad = n_bad + excluded.n_bad,
                 last_ok = excluded.last_ok, ts = excluded.ts""",
            (uid, qid, int(ok), int(not ok), int(ok), now),
        )
        row = c.execute("SELECT box, due FROM srs WHERE user_id=? AND qid=?", (uid, qid)).fetchone()
        if not ok:                                   # xato → 1 kundan keyin qaytadi
            c.execute("INSERT OR REPLACE INTO srs(user_id, qid, box, due) VALUES(?,?,?,?)",
                      (uid, qid, 1, now + SRS_DAYS[1] * 86400))
        elif row and row[1] <= now:                  # muddati kelgan savol to'g'ri → keyingi bosqich
            if row[0] >= 3:
                c.execute("DELETE FROM srs WHERE user_id=? AND qid=?", (uid, qid))
            else:
                nb = row[0] + 1
                c.execute("UPDATE srs SET box=?, due=? WHERE user_id=? AND qid=?",
                          (nb, now + SRS_DAYS[nb] * 86400, uid, qid))
        st = _settings(c, uid)
        day = _dayfmt(now + st["tz"] * 3600)
        c.execute("INSERT OR IGNORE INTO daily(user_id, day) VALUES(?,?)", (uid, day))
        c.execute("UPDATE daily SET n=n+1, ok=ok+? WHERE user_id=? AND day=?", (int(ok), uid, day))
        n, met = c.execute("SELECT n, met FROM daily WHERE user_id=? AND day=?", (uid, day)).fetchone()
        just = False
        if n >= st["goal"] and not met:
            c.execute("UPDATE daily SET met=1 WHERE user_id=? AND day=?", (uid, day))
            just = True
        streak = _streak(c, uid, st["tz"], now)
    return dict(n=n, goal=st["goal"], just_met=just, streak=streak)


def srs_due(uid: int, now: float = None) -> list:
    with _db() as c:
        rows = c.execute("SELECT qid FROM srs WHERE user_id=? AND due<=? ORDER BY due",
                         (uid, now or time.time())).fetchall()
    return [r[0] for r in rows]


def srs_counts(uid: int, now: float = None):
    with _db() as c:
        due = c.execute("SELECT COUNT(*) FROM srs WHERE user_id=? AND due<=?",
                        (uid, now or time.time())).fetchone()[0]
        total = c.execute("SELECT COUNT(*) FROM srs WHERE user_id=?", (uid,)).fetchone()[0]
    return due, total


def progress(uid: int, now: float = None) -> dict:
    now = now or time.time()
    with _db() as c:
        st = _settings(c, uid)
        day = _dayfmt(now + st["tz"] * 3600)
        r = c.execute("SELECT n FROM daily WHERE user_id=? AND day=?", (uid, day)).fetchone()
        due = c.execute("SELECT COUNT(*) FROM srs WHERE user_id=? AND due<=?", (uid, now)).fetchone()[0]
        total = c.execute("SELECT COUNT(*) FROM srs WHERE user_id=?", (uid,)).fetchone()[0]
        streak = _streak(c, uid, st["tz"], now)
    return dict(n=r[0] if r else 0, goal=st["goal"], streak=streak, due=due, srs_total=total)


def users_to_remind(now: float = None) -> list:
    """Eslatma vaqti kelgan (va bugungi maqsadi bajarilmagan) foydalanuvchilar."""
    now = now or time.time()
    out = []
    with _db() as c:
        rows = c.execute(
            "SELECT user_id, remind, goal, tz, last_sent, exam_date FROM settings WHERE remind IS NOT NULL"
        ).fetchall()
        for uid, remind, goal, tz, last, exam_date in rows:
            local = now + tz * 3600
            day = _dayfmt(local)
            mins = int(local % 86400 // 60)
            if last == day or not (remind <= mins < remind + 120):
                continue
            c.execute("UPDATE settings SET last_sent=? WHERE user_id=?", (day, uid))
            r = c.execute("SELECT n, met FROM daily WHERE user_id=? AND day=?", (uid, day)).fetchone()
            n, met = r if r else (0, 0)
            if met:
                continue
            due = c.execute("SELECT COUNT(*) FROM srs WHERE user_id=? AND due<=?", (uid, now)).fetchone()[0]
            out.append(dict(uid=uid, n=n, goal=goal, due=due, streak=_streak(c, uid, tz, now),
                            exam_date=exam_date, today=day))
    return out


def wrong_ids(uid: int) -> list:
    with _db() as c:
        rows = c.execute(
            "SELECT qid FROM answers WHERE user_id=? AND last_ok=0", (uid,)
        ).fetchall()
    return [r[0] for r in rows]


def save_exam(uid: int, cls: int, correct: int, total: int, seconds: int) -> None:
    with _db() as c:
        c.execute(
            "INSERT INTO exams(user_id, cls, correct, total, seconds, ts) VALUES(?,?,?,?,?,?)",
            (uid, cls, correct, total, seconds, time.time()),
        )


def user_stats(uid: int) -> dict:
    with _db() as c:
        a = c.execute(
            "SELECT COUNT(*), COALESCE(SUM(n_ok),0), COALESCE(SUM(n_bad),0), "
            "COALESCE(SUM(CASE WHEN last_ok=0 THEN 1 ELSE 0 END),0) "
            "FROM answers WHERE user_id=?", (uid,),
        ).fetchone()
        ex = c.execute(
            "SELECT cls, correct, total, ts FROM exams WHERE user_id=? ORDER BY id DESC LIMIT 5",
            (uid,),
        ).fetchall()
    return dict(unique=a[0], ok=a[1], bad=a[2], wrong_now=a[3], exams=ex)


# ---------------------------------------------------------------- tarjima keshi
def get_tr(qid: int):
    with _db() as c:
        row = c.execute("SELECT data FROM tr WHERE qid=?", (qid,)).fetchone()
    return json.loads(row[0]) if row else None


def set_tr(qid: int, data: dict) -> None:
    with _db() as c:
        c.execute("INSERT OR REPLACE INTO tr(qid, data) VALUES(?,?)",
                  (qid, json.dumps(data, ensure_ascii=False)))


def format_translation(q: dict, tr: dict, reveal: bool = False) -> str:
    parts = [f"🌐 <b>№ {q['id']} — o'zbekcha tarjima</b>",
             "<i>(mashina tarjimasi, taxminiy)</i>", "", esc(tr["q"])]
    if tr.get("ctx"):
        parts += ["", "\n".join("📍 " + esc(c) for c in tr["ctx"])]
    parts.append("")
    for i, o in enumerate(tr["o"], start=1):
        body = f"<u>{esc(o)}</u>" if (reveal and i in q["a"]) else esc(o)
        parts.append(f"{CIRCLED[i - 1]} {body}")
    text = "\n".join(parts)
    if reveal and tr.get("e"):
        room = MAX_LEN - len(text) - 40
        if room > 50:
            text += "\n\n💡 <b>Izoh:</b> " + esc(tr["e"][:room])
    return text


# ---------------------------------------------------------------- saralanganlar
def toggle_saved(uid: int, qid: int) -> bool:
    with _db() as c:
        if c.execute("SELECT 1 FROM saved WHERE user_id=? AND qid=?", (uid, qid)).fetchone():
            c.execute("DELETE FROM saved WHERE user_id=? AND qid=?", (uid, qid))
            return False
        c.execute("INSERT INTO saved(user_id, qid, ts) VALUES(?,?,?)", (uid, qid, time.time()))
        return True


def is_saved(uid, qid: int) -> bool:
    if uid is None:
        return False
    with _db() as c:
        return c.execute("SELECT 1 FROM saved WHERE user_id=? AND qid=?", (uid, qid)).fetchone() is not None


def saved_ids(uid: int) -> list:
    with _db() as c:
        return [r[0] for r in c.execute("SELECT qid FROM saved WHERE user_id=? ORDER BY ts DESC", (uid,))]


def clear_saved(uid: int) -> None:
    with _db() as c:
        c.execute("DELETE FROM saved WHERE user_id=?", (uid,))


def answers_map(uid: int) -> dict:
    with _db() as c:
        return {r[0]: (r[1], r[2]) for r in c.execute(
            "SELECT qid, n_ok, n_bad FROM answers WHERE user_id=?", (uid,))}


# ---------------------------------------------------------------- bot sozlamalari / kirish
def get_bs(key: str, default=None):
    with _db() as c:
        r = c.execute("SELECT value FROM bot_settings WHERE key=?", (key,)).fetchone()
    return r[0] if r else default


def set_bs(key: str, value) -> None:
    with _db() as c:
        c.execute("INSERT OR REPLACE INTO bot_settings(key, value) VALUES(?,?)", (key, str(value)))


def add_allowed(uid: int, name: str, by: int) -> None:
    with _db() as c:
        c.execute("INSERT OR REPLACE INTO allowed(user_id, name, added_by, ts) VALUES(?,?,?,?)",
                  (uid, name, by, time.time()))


def remove_allowed(uid: int) -> bool:
    with _db() as c:
        return c.execute("DELETE FROM allowed WHERE user_id=?", (uid,)).rowcount > 0


def is_allowed_db(uid: int) -> bool:
    with _db() as c:
        return c.execute("SELECT 1 FROM allowed WHERE user_id=?", (uid,)).fetchone() is not None


def list_allowed() -> list:
    with _db() as c:
        return c.execute("SELECT user_id, name FROM allowed ORDER BY ts").fetchall()


def create_invite(by: int) -> str:
    import secrets
    code = secrets.token_urlsafe(8)
    with _db() as c:
        c.execute("INSERT INTO invites(code, created_by, ts) VALUES(?,?,?)", (code, by, time.time()))
    return code


def redeem_invite(code: str, uid: int, name: str, ttl_days: int = 7) -> bool:
    with _db() as c:
        r = c.execute("SELECT ts, used_by FROM invites WHERE code=?", (code,)).fetchone()
        if not r or r[1] is not None or time.time() - r[0] > ttl_days * 86400:
            return False
        c.execute("UPDATE invites SET used_by=? WHERE code=?", (uid, code))
        c.execute("INSERT OR REPLACE INTO allowed(user_id, name, added_by, ts) VALUES(?,?,?,?)",
                  (uid, name, 0, time.time()))
    return True


# ---------------------------------------------------------------- reyting
def lb_join(chat_id: int, uid: int, name: str, title: str = "") -> None:
    with _db() as c:
        c.execute("INSERT OR REPLACE INTO lb_members(chat_id, user_id, name) VALUES(?,?,?)",
                  (chat_id, uid, name))
        c.execute("INSERT OR REPLACE INTO lb_groups(chat_id, title) VALUES(?,?)", (chat_id, title))


def lb_leave(chat_id: int, uid: int) -> None:
    with _db() as c:
        c.execute("DELETE FROM lb_members WHERE chat_id=? AND user_id=?", (chat_id, uid))


def lb_members(chat_id: int) -> list:
    with _db() as c:
        return c.execute("SELECT user_id, name FROM lb_members WHERE chat_id=?", (chat_id,)).fetchall()


def lb_groups_of(uid: int) -> list:
    with _db() as c:
        return c.execute(
            "SELECT g.chat_id, g.title FROM lb_members m JOIN lb_groups g ON g.chat_id=m.chat_id "
            "WHERE m.user_id=?", (uid,)).fetchall()


def lb_title(chat_id: int, title: str) -> None:
    with _db() as c:
        c.execute("INSERT OR REPLACE INTO lb_groups(chat_id, title) VALUES(?,?)", (chat_id, title))


def weekly_scores(uids: list, start_day: str, end_day: str) -> dict:
    out = {}
    with _db() as c:
        for uid in uids:
            r = c.execute("SELECT COALESCE(SUM(n),0), COALESCE(SUM(ok),0) FROM daily "
                          "WHERE user_id=? AND day>=? AND day<=?", (uid, start_day, end_day)).fetchone()
            out[uid] = (r[0], r[1])
    return out


# ---------------------------------------------------------------- flashcard (oraliqli takrorlash)
CARD_DAYS = {1: 1, 2: 3, 3: 7, 4: 14, 5: 30}     # quti -> kun
CARD_LEARNED_BOX = 4                              # 14 kun va undan uzoq = o'zlashtirilgan


def card_queue(uid: int, source_ids=None, new_limit: int = 15, now: float = None) -> list:
    """Avval muddati kelgan kartalar, keyin yangi (hali ko'rilmagan) kartalar — raqam tartibida."""
    now = now or time.time()
    src = list(source_ids) if source_ids is not None else list(ALL_IDS)
    src_set = set(src)
    with _db() as c:
        rows = c.execute("SELECT qid, due FROM cards WHERE user_id=?", (uid,)).fetchall()
    seen = {r[0] for r in rows}
    due = [r[0] for r in sorted(rows, key=lambda r: r[1]) if r[1] <= now and r[0] in src_set]
    new = [q for q in sorted(src) if q not in seen][:new_limit]
    return due + new


def card_grade(uid: int, qid: int, known: bool, now: float = None) -> dict:
    now = now or time.time()
    with _db() as c:
        row = c.execute("SELECT box, reps FROM cards WHERE user_id=? AND qid=?", (uid, qid)).fetchone()
        box, reps = (row[0], row[1]) if row else (0, 0)
        if known:
            box = min(5, box + 1)
            due = now + CARD_DAYS[box] * 86400
        else:
            box, due = 0, now + 600                 # 10 daqiqadan keyin yana
        c.execute("INSERT OR REPLACE INTO cards(user_id, qid, box, due, reps) VALUES(?,?,?,?,?)",
                  (uid, qid, box, due, reps + 1))
    return dict(box=box, due=due)


def card_stats(uid: int, now: float = None) -> dict:
    now = now or time.time()
    with _db() as c:
        total, due, learned = c.execute(
            "SELECT COUNT(*), COALESCE(SUM(CASE WHEN due<=? THEN 1 ELSE 0 END),0), "
            "COALESCE(SUM(CASE WHEN box>=? THEN 1 ELSE 0 END),0) FROM cards WHERE user_id=?",
            (now, CARD_LEARNED_BOX, uid)).fetchone()
    return dict(total=total, due=due, learned=learned, new=TOTAL - total)
